<template>
	           <!-- Begin FB's Footer Area -->
            <div class="fb-footer">
                <!-- Begin Footer Top Area -->
                <div class="fb-footer_top">
                    <div class="container">
                        <div class="row">
                            <!-- Begin FB's Newsletters Area -->
                            <div class="col-lg-5">
                                <div class="fb-newsletters">
                                    <h2 class="newsletters-headeing">Sign Up For Newsletters</h2>
                                    <p class="short-desc">Be The First To Know. Sign Up For Newsletter Today</p>
                                </div>
                            </div>
                            <!-- FB's Newsletters Area End Here -->
                            <!-- Begin FB's Newsletters Form Area -->
                            <div class="col-lg-7">
                                <div class="fb-newsletters_form pt-sm-15 pt-xs-15">
                                    <form action="http://devitems.us11.list-manage.com/subscribe/post?u=6bbb9b6f5827bd842d9640c82&amp;id=05d85f18ef" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="footer-subscribe-form validate" target="_blank" novalidate>
                                       <div id="mc_embed_signup_scroll">
                                          <div id="mc-form" class="mc-form subscribe-form form-group" >
                                            <input id="mc-email" type="email" autocomplete="off" placeholder="Enter your email" />
                                            <button  class="btn mt-sm-15 mt-xs-15" id="mc-submit">Subscribe!</button>
                                          </div>
                                       </div>
                                    </form>
                                </div>
                            </div>
                            <!-- FB's Newsletters Form Area End Here -->
                        </div>
                    </div>
                </div>
                <!-- Footer Top Area End Here -->
                <!-- Begin FB's Footer Middle Area -->
                <div class="fb-footer_middle bg-white">
                    <div class="container">
                        <!-- Begin Footer Middle Top Area -->
                        <div class="footer-middle_top">
                            <div class="row">
                                <!-- Begin FB's Footer Widget Area -->
                                <div class="col-xl-2 col-lg-2 col-md-3 col-sm-5">
                                    <div class="fb-footer_widget pt-20">
                                        <h3 class="fb-footer-widget-headeing">Products</h3>
                                        <ul>
                                            <li><a href="#">Prices drop</a></li>
                                            <li><a href="#">New products</a></li>
                                            <li><a href="#">Best sales</a></li>
                                            <li><a href="#">Login</a></li>
                                            <li><a href="#">My account</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- FB's Footer Widget Area End Here -->
                                <!-- Begin FB's Footer Widget Area -->
                                <div class="col-xl-3 col-lg-3 col-md-5 col-sm-7">
                                    <div class="fb-footer_widget pt-20 pt-xs-0">
                                        <h3 class="fb-footer-widget-headeing">Our company</h3>
                                        <ul>
                                            <li><a href="#">Delivery</a></li>
                                            <li><a href="#">Legal Notice</a></li>
                                            <li><a href="#">Terms and conditions of use</a></li>
                                            <li><a href="#">About us</a></li>
                                            <li><a href="#">Contact us</a></li>
                                            <li><a href="#">Stores</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- FB's Footer Widget Area End Here -->
                                <!-- Begin FB's Footer Widget Area -->
                                <div class="col-xl-2 col-lg-2 col-md-4 col-sm-5">
                                    <div class="fb-footer_widget pt-20 pt-xs-0">
                                        <h3 class="fb-footer-widget-headeing">Your account</h3>
                                        <ul>
                                            <li><a href="#">Addresses</a></li>
                                            <li><a href="#">Credit slips</a></li>
                                            <li><a href="#">Orders</a></li>
                                            <li><a href="#">Personal info</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- FB's Footer Widget Area End Here -->
                                <!-- Begin FB's Footer Widget Area -->
                                <div class="col-xl-5 col-lg-5 col-sm-7">
                                    <div class="footer-widget-logo pt-30 mb-20 pt-sm-5 pt-xs-5">
                                        <a href="index.html">
                                            <img src="assets/images/menu/logo/2.png" alt="FB's Logo">
                                        </a>
                                    </div>
                                    <div class="footer-widget-info">
                                        <p class="footer-widget_short-desc">We are a team of designers and developers that create high quality HTML Template & Woocommerce, Shopify Theme.
                                        </p>
                                        <div class="footer-widget_address">
                                            <h2>Contact info:</h2>
                                            <p>169-C, Technohub, Dubai Silicon Oasis.</p>
                                        </div>
                                        <div class="footer-widget-social-link">
                                            <ul class="social-link">
                                                <li class="facebook">
                                                    <a href="https://www.facebook.com/" data-toggle="tooltip" target="_blank" title="Facebook">
                                                        <i class="fa fa-facebook"></i>
                                                    </a>
                                                </li>
                                                <li class="twitter">
                                                    <a href="https://twitter.com/" data-toggle="tooltip" target="_blank" title="Twitter">
                                                        <i class="fa fa-twitter"></i>
                                                    </a>
                                                </li>
                                                <li class="youtube">
                                                    <a href="https://www.youtube.com/" data-toggle="tooltip" target="_blank" title="Youtube">
                                                        <i class="fa fa-youtube"></i>
                                                    </a>
                                                </li>
                                                <li class="google-plus">
                                                    <a href="https://www.plus.google.com/discover" data-toggle="tooltip" target="_blank" title="Google Plus">
                                                        <i class="fa fa-google-plus"></i>
                                                    </a>
                                                </li>
                                                <li class="instagram">
                                                    <a href="https://www.instagram.com/" data-toggle="tooltip" target="_blank" title="Instagram">
                                                        <i class="fa fa-instagram"></i>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <!-- FB's Footer Widget Area End Here -->
                            </div>
                        </div>
                        <!-- Footer Middle Top Area End Here -->
                        <!-- Begin Footer Middle Bottom Area -->
                        <div class="footer-middle-bottom">
                            <div class="row">
                                <div class="col-lg-12">
                                    <!-- Begin Footer Tag Link Area -->
                                    <div class="footer-tag-links pt-20 pb-20">
                                        <ul>
                                            <li><a href="#">Online Shopping</a></li>
                                            <li><a href="#">Promotions</a></li>
                                            <li><a href="#">My Orders</a></li>
                                            <li><a href="#">Help</a></li>
                                            <li><a href="#">Customer Service</a></li>
                                            <li><a href="#">Support</a></li>
                                            <li><a href="#">Most Populars</a></li>
                                            <li><a href="#">New Arrivals</a></li>
                                            <li><a href="#">Special Products</a></li>
                                            <li><a href="#">Manufacturers</a></li>
                                            <li><a href="#">Our Stores</a></li>
                                            <li><a href="#">Shipping</a></li>
                                            <li><a href="#">Payments</a></li>
                                            <li><a href="#">Warantee</a></li>
                                            <li><a href="#">Refunds</a></li>
                                            <li><a href="#">Checkout</a></li>
                                            <li><a href="#">Discount</a></li>
                                            <li><a href="#">Terms & Conditions</a></li>
                                            <li><a href="#">Policy</a></li>
                                            <li><a href="#">Shipping</a></li>
                                            <li><a href="#">Payments</a></li>
                                            <li><a href="#">Returns</a></li>
                                            <li><a href="#">Refunds</a></li>
                                        </ul>
                                    </div>
                                    <!-- Footer Tag Link Area End Here -->
                                    <!-- Begin Footer Payment Area -->
                                    <div class="payment text-center pb-30">
                                        <a href="#">
                                            <img src="assets/images/payment/1.png" alt="FB's Footer Payment">
                                        </a>
                                    </div>
                                    <!-- Footer Payment Area End Here -->
                                </div>
                            </div>
                        </div>
                        <!-- Footer Middle Bottom Area End Here -->
                    </div>
                </div>
                <!-- FB's Footer Middle Area End Here -->
                <!-- Begin Footer Bottom Area -->
                <div class="footer-bottom">
                    <div class="container">
                        <div class="row">
                            <!-- Begin Copyright Area -->
                            <div class="col-lg-6 col-md-6">
                                <div class="copyright">
                                    <span>Copyright &copy; 2018 <a href="#">Fastbuy.</a> All rights reserved.</span>
                                </div>
                            </div>
                            <!-- Copyright Area End Here -->
                            <!-- Begin Footer Bottom Menu Area -->
                            <div class="col-lg-6 col-md-6">
                                <div class="fotter-bottom_menu">
                                    <ul>
                                        <li><a href="index.html">Home</a></li>
                                        <li><a href="about-us.html">About</a></li>
                                        <li><a href="shop-left-sidebar.html">Shop</a></li>
                                        <li><a href="contact.html">Contact</a></li>
                                    </ul>
                                </div>
                            </div>
                            <!-- Footer Bottom Menu Area End Here -->
                        </div>
                    </div>
                </div>
                <!-- Footer Bottom Area End Here -->
            </div>
            <!-- FB's Footer Area End Here -->
</template>


<script>
    export default {
        mounted() {
            console.log('Footer Component mounted.')
        }
    }
</script>