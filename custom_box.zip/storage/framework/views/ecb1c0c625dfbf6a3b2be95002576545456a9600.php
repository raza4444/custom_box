       <?php if(count($MainCategoryProducts) > 0): ?>

       <?php $__currentLoopData = $MainCategoryProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mainCategoryDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- Begin FB's Banner With List Product Area -->
        <div class="fb-banner_with_list-product cookware-product pt-60 pb-60">
            <div class="container">
                <div class="fb-product_list_nav">
                    <div class="row no-gutters">
                        <div class="col-xl-3 col-lg-4 col-md-5">
                            <div class="fb-section_title-2">
                                <h2><?php echo e($mainCategoryDetail['category_name']); ?></h2>
                            </div>
                            <!-- Begin FB's Banner Area -->
                            <div class="fb-banner fb-img-hover-effect">
                                <a href="#">
                                    
                                    <img src="<?php echo e(URL::to('uploads/sections/'.$mainCategoryDetail['category_image'])); ?>" alt="FB'S Banner">
                                </a>
                            </div>
                            <!-- FB's Banner Area End Here -->
                        </div>
                        <div class="col-xl-9 col-lg-8 col-md-7">
                            <div class="btn-group">
                                <button class="subcategories-trigger"><i class="fa fa-bars"></i></button>
                                
                             <!-- Begin FB's List Product Menu Area -->
                             
                            <!-- FB's List Product Menu Area End Here -->
                        </div>
                        <!-- Begin FB's List Product Area -->
                        <div class="fb-list_product">
                           
                             <div  class="fb-list_product_active owl-carousel">
                            <!-- Begin Sigle Product Area -->
                           
                           <?php $__currentLoopData = $mainCategoryDetail['category_products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $Topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($key <= 10): ?>
                                    <?php
                                    if ($Topic->$title_var != "") {
                                        $title = $Topic->$title_var;
                                    } else {
                                        $title = $Topic->$title_var2;
                                    }
                                    if ($Topic->$details_var != "") {
                                        $details = $details_var;
                                    } else {
                                        $details = $details_var2;
                                    }
                                    $section = "";
                                    try {
                                        if ($Topic->section->$title_var != "") {
                                            $section = $Topic->section->$title_var;
                                        } else {
                                            $section = $Topic->section->$title_var2;
                                        }
                                    } catch (Exception $e) {
                                        $section = "";
                                    }

                                    // set row div
                                    if (($i == 1 && count($Categories) > 0) || ($i == 2 && count($Categories) == 0)) {
                                        $i = 0;
                                        echo "</div><div class='row'>";
                                    }
                                    if ($Topic->$slug_var != "" && Helper::GeneralWebmasterSettings("links_status")) {
                                        if (trans('backLang.code') != env('DEFAULT_LANGUAGE')) {
                                            $topic_link_url = url(trans('backLang.code') . "/" . $Topic->$slug_var);
                                        } else {
                                            $topic_link_url = url($Topic->$slug_var);
                                        }
                                    } else {
                                        $topic_link_url = route('FrontendProduct', ["id" => $Topic->id]);
                                    }
                                    ?> 
                            <div class="single-product">
                                <!-- Begin Product Image Area -->
                                <div class="product-img">
                                    <a href="<?php echo e($topic_link_url); ?>">
                                        <?php if($Topic->photo_file !=""): ?>
                                        <img class="primary-img" src="<?php echo e(URL::to('uploads/topics/'.$Topic->photo_file)); ?>" alt="FB'S Prduct">
                                        <?php endif; ?>
                                                <?php if(count($Topic->photos)>0): ?>
                                             <?php $__currentLoopData = $Topic->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <?php if($key == '1' || $key == 1): ?>
                                                    <img class="secondary-img" src="<?php echo e(URL::to('uploads/topics/'.$photo->file)); ?>"
                                                                         alt="<?php echo e($photo->title); ?>">
                                                    <?php endif; ?>
                                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                    </a>
                                    <div class="countersection">
                                       
                                    </div>
                                </div>
                                <!-- Product Image Area End Here -->
                                <!-- Begin Product Content Area -->
                                <div class="product-content">
                                    <h2 class="product-name">
                                        <a href="<?php echo e($topic_link_url); ?>"> <?php echo e($title); ?></a>
                                    </h2>
                                    
                                </div>
                                <!-- Product Content Area End Here -->
                            </div>
                            <!-- Sigle Product Area End Here -->
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                        </div>
                        <!-- FB's List Product Area End Here -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- FB's Banner With List Product Area End Here -->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>