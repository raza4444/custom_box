
<!-- Begin Header Bottom Menu Area -->
<div class="col-lg-9 d-none d-lg-block d-xl-block position-static">
    <!-- FB's Navigation -->
    <nav class="fb-navigation">
        <ul>
            <li class="active">
                <a href="<?php echo e(route('Home')); ?>">Home</a>

            </li>
          <?php $__currentLoopData = $SearchCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <li class="dropdown-holder">
                                            <a href="shop-left-sidebar.html"><?php echo e($Category->$category_title_var); ?></a>
                                            <?php if(count($Category->fatherSections)>0): ?>
                                            <ul class="hb-dropdown hb-dropdown-2">
                                                  <?php $__currentLoopData = $Category->fatherSections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $MnuCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><a href="shop-left-sidebar.html"><?php echo e($MnuCategory->$category_title_var); ?></a>
                                                    <?php if(count($MnuCategory->fatherSections)>0): ?>
                                                    <ul>
                                                        <?php $__currentLoopData = $MnuCategory->fatherSections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $MnusubCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li><a href="shop-3-column.html"><?php echo e($MnusubCategory->$category_title_var); ?></a></li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        
                                                    </ul>
                                                    <?php endif; ?>
                                                </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                               
                                                
                                            </ul>
                                            <?php endif; ?>
                                        </li>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                        

            <li >
                <a href="<?php echo e(url('blogs')); ?>">Blog</a>
               
            </li>
            <li>
                <a href="<?php echo e(url('about')); ?>">About Us</a>
            </li>
           
        </ul>
    </nav>
    <!--FB's Navigation -->
</div>
                            <!-- Header Bottom Menu Area End Here -->