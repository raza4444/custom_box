 <div class="col-lg-12">
    <div class="slider-area">
         <?php if(count($SliderBanners)>0): ?>
        <div class="slider-active owl-carousel">
           
            <?php $__currentLoopData = $SliderBanners->slice(0,1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $SliderBanner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            try {
                $SliderBanner_type = $SliderBanner->webmasterBanner->type;
            } catch (Exception $e) {
                $SliderBanner_type = 0;
            }
            ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php
        $title_var = "title_" . trans('backLang.boxCode');
        $details_var = "details_" . trans('backLang.boxCode');
        $file_var = "file_" . trans('backLang.boxCode');
        ?> <?php if($SliderBanner_type==0): ?>
            
            <div class="text-center">
                <?php $__currentLoopData = $SliderBanners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $SliderBanner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($SliderBanner->$details_var !=""): ?>
                        <div><?php echo $SliderBanner->$details_var; ?></div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
             <?php elseif($SliderBanner_type==1): ?>
             <?php $__currentLoopData = $SliderBanners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $SliderBanner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!-- Begin Single Slide Area -->
            <div class="single-slide align-center-left  animation-style-01 bg-1" style="background-image: url(<?php echo e(URL::to('uploads/banners/'.$SliderBanner->$file_var)); ?>);">
                <div class="slider-progress"></div>
                <div class="slider-content">
                    <?php if($SliderBanner->$details_var !=""): ?>
                                    <h2><?php echo $SliderBanner->$title_var; ?></h2>
                                <?php endif; ?>
                  <?php if($SliderBanner->$details_var !=""): ?>
                                    <h5><?php echo nl2br($SliderBanner->$details_var); ?></h5>
                                <?php endif; ?>
                                 <?php if($SliderBanner->link_url !=""): ?>
                    <div class="default-btn slide-btn">
                        <a class="fb-links fb-links-round" href="<?php echo $SliderBanner->link_url; ?>">Shop Now</a>
                    </div>
                      <?php endif; ?>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <!-- Single Slide Area End Here -->

        </div>
        <?php endif; ?>
    </div>
</div>