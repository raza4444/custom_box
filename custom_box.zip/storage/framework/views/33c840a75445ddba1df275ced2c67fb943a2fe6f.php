<?php $__env->startSection('content'); ?>
<?php
    $title_var = "title_" . trans('backLang.boxCode');
    $title_var2 = "title_" . trans('backLang.boxCodeOther');
    $details_var = "details_" . trans('backLang.boxCode');
    $details_var2 = "details_" . trans('backLang.boxCodeOther');
    if ($Topic->$title_var != "") {
        $title = $Topic->$title_var;
    } else {
        $title = $Topic->$title_var2;
    }
    if ($Topic->$details_var != "") {
        $details = $details_var;
    } else {
        $details = $details_var2;
    }
    $section = "";
    try {
        if ($Topic->section->$title_var != "") {
            $section = $Topic->section->$title_var;
        } else {
            $section = $Topic->section->$title_var2;
        }
    } catch (Exception $e) {
        $section = "";
    }
    ?>
<!-- Begin FB's Breadcrumb Area -->
            <div class="breadcrumb-area pt-30 pb-30">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="breadcrumb-content">
                                <ul>
                                    <li><a href="<?php echo e(route("Home")); ?>"><i class="fa fa-home"></i></a><i class="icon-angle-right"></i>
                        </li>
                        <?php if($WebmasterSection->id != 1): ?>
                            <li class="active"><?php echo trans('backLang.'.$WebmasterSection->name); ?></li>
                        <?php else: ?>
                            <li class="active"><?php echo e($title); ?></li>
                        <?php endif; ?>
                        <?php if(!empty($CurrentCategory)): ?>
                            <?php
                            $category_title_var = "title_" . trans('backLang.boxCode');
                            ?>
                            <li class="active"><i
                                        class="icon-angle-right"></i><?php echo e($CurrentCategory->$category_title_var); ?></li>
                        <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- FB's Breadcrumb Area End Here -->
                 <!--page content area-->
            <div class="page-content">
                               <!-- Product Details Area -->
                <div class="product-details-area">
                    <div class="container">
                        <div class="">
                            <div class="row">

                             <?php if($Topic->photo_file !=""): ?>
                                                    
                                                  
                                            <div class="pdetails-singleimage" data-src="<?php echo e(URL::to('uploads/topics/'.$Topic->photo_file)); ?>">
                                                <img src="<?php echo e(URL::to('uploads/topics/'.$Topic->photo_file)); ?>" alt="product image">
                                                
                                            </div>
                                              <?php endif; ?>

                                            <br><br/>
                                            <div class=" ">
                                                <?php echo $Topic->$details; ?>

                                            </div>
                                            <br><br/>
                                            <br>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>