<?php $__env->startSection('content'); ?>

<!-- Begin Li's Breadcrumb Area -->
<div class="breadcrumb-area pt-30 pb-30">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="breadcrumb-content">
					<ul>
						<li><a href="<?php echo e(route("Home")); ?>">Home</a></li>
						<?php if(@$WebmasterSection!="none"): ?>
						<li class="active"><?php echo trans('backLang.'.$WebmasterSection->name); ?></li>
						<?php elseif(@$search_word!=""): ?>
						<li class="active"><?php echo e(@$search_word); ?></li>
						<?php else: ?>
						<li class="active"><?php echo e($User->name); ?></li>
						<?php endif; ?>
						<?php if($CurrentCategory!="none"): ?>
						<?php if(!empty($CurrentCategory)): ?>
						<?php
						$category_title_var = "title_" . trans('backLang.boxCode');
						?>
						<li class="active"><i
							class="icon-angle-right"></i><?php echo e($CurrentCategory->$category_title_var); ?>

						</li>
						<?php endif; ?>
						<?php endif; ?>
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- Li's Breadcrumb Area End Here -->

<div class="content-wraper">
	<div class="container">
		<div class="row">
			<div class="col-lg-9 order-1 order-lg-2">
				<!-- Begin FB's Banner Area -->
				<div class="shoptopbar-heading">
					<?php if($CurrentCategory!="none"): ?>
					<?php
					$category_title_var = "title_" . trans('backLang.boxCode');
					?>
					<h2><?php echo e($CurrentCategory->$category_title_var); ?></h2>
					<?php else: ?> 
					<?php if(@$WebmasterSection!="none"): ?>
					<?php echo e($WebmasterSection->name); ?>

					<?php endif; ?>
					<?php endif; ?>
				</div>

				<!-- shop-products-wrapper start -->
				<?php if($Topics->total() > 0): ?>

				<?php
				$title_var = "title_" . trans('backLang.boxCode');
				$title_var2 = "title_" . trans('backLang.boxCodeOther');
				$details_var = "details_" . trans('backLang.boxCode');
				$details_var2 = "details_" . trans('backLang.boxCodeOther');
				$slug_var = "seo_url_slug_" . trans('backLang.boxCode');
				$slug_var2 = "seo_url_slug_" . trans('backLang.boxCodeOther');
				$i = 0;
				?>
				<div class="shop-products-wrapper bg-white mt-30 pb-60 pb-sm-30">
					<div class="tab-content">
						<div id="grid-view" class="tab-pane fade active show" role="tabpanel">
							<div class="fb-product_wrap shop-product-area">
								<div class="row">
									<?php $__currentLoopData = $Topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php
									if ($Topic->$title_var != "") {
										$title = $Topic->$title_var;
									} else {
										$title = $Topic->$title_var2;
									}
									if ($Topic->$details_var != "") {
										$details = $details_var;
									} else {
										$details = $details_var2;
									}
									$section = "";
									try {
										if ($Topic->section->$title_var != "") {
											$section = $Topic->section->$title_var;
										} else {
											$section = $Topic->section->$title_var2;
										}
									} catch (Exception $e) {
										$section = "";
									}

                                    // set row div
									if (($i == 1 && count($Categories) > 0) || ($i == 2 && count($Categories) == 0)) {
										$i = 0;
										echo "</div><div class='row'>";
									}
									if ($Topic->$slug_var != "" && Helper::GeneralWebmasterSettings("links_status")) {
										if (trans('backLang.code') != env('DEFAULT_LANGUAGE')) {
											$topic_link_url = url(trans('backLang.code') . "/" . $Topic->$slug_var);
										} else {
											$topic_link_url = url($Topic->$slug_var);
										}
									} else {
										$topic_link_url = route('FrontendProduct', ["id" => $Topic->id]);
									}
									?>
									<div class="col-lg-4 col-md-4 col-sm-6">
										<!-- Begin Sigle Product Area -->
										<div class="single-product">
											<!-- Begin Product Image Area -->
											<div class="product-img">

												<a href="<?php echo e($topic_link_url); ?>">
													<?php if($Topic->photo_file !=""): ?>
													<img class="primary-img" src="<?php echo e(URL::to('uploads/topics/'.$Topic->photo_file)); ?>" >
													<?php endif; ?>
													<?php if(count($Topic->photos)>0): ?>
											 <?php $__currentLoopData = $Topic->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											 <?php if($key == '1' || $key == 1): ?>
													<img class="secondary-img" src="<?php echo e(URL::to('uploads/topics/'.$photo->file)); ?>"
                                                                         alt="<?php echo e($photo->title); ?>">
													<?php endif; ?>
													 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													<?php endif; ?>
												</a>


											</div>
											<!-- Product Image Area End Here -->
											<!-- Begin Product Content Area -->
											<div class="product-content">
												<h2 class="product-name">
													<a href="<?php echo e($topic_link_url); ?>"> <?php echo e($title); ?></a>
												</h2>


												<div class="product-action">
													<ul class="product-action-link">
														
														<li class="quick-view-btn"><a href="#" title="Quick View" data-toggle="modal" data-target="#exampleModalCenter"><i class="ion-eye"></i></a></li>
														
													</ul>
												</div>
											</div>
											<!-- Product Content Area End Here -->
										</div>
										<!-- Sigle Product Area End Here -->
									</div>

									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

									<!--here finish-->


								</div>
							</div>
						</div>
					</div>
				</div>
				<?php endif; ?>

				<!-- shop-products-wrapper start -->

				<!-- shop-top-bar end -->
			</div>


			<!--sidebar-->
			<?php echo $__env->make('frontEnd.pages.products.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<!--end-->


		</div>
	</div>
</div>
<br><br><br><br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>