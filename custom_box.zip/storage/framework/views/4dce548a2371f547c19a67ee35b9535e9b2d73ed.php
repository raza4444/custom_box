<div class="col-lg-3 order-2 order-lg-1">
    <div class="sidebar-title">
       <?php if($CurrentCategory!="none"): ?>
       <?php
       $category_title_var = "title_" . trans('backLang.boxCode');
       ?>
       <h2><?php echo e($CurrentCategory->$category_title_var); ?></h2>
       <?php else: ?> 
       <?php if(@$WebmasterSection!="none"): ?>
       <?php echo e($WebmasterSection->name); ?>

       <?php endif; ?>
        <?php endif; ?>

   </div>
   <?php if(count($Categories)>0): ?>
   <?php
   $category_title_var = "title_" . trans('backLang.boxCode');
   $slug_var = "seo_url_slug_" . trans('backLang.boxCode');
   $slug_var2 = "seo_url_slug_" . trans('backLang.boxCodeOther');
   ?>
   <!--Begin Sidebar Categores Box Area -->
   <div class="sidebar-categores-box mt-sm-30 mt-xs-30">
    <!-- Begin Category Sub Menu Area -->
    <div class="category-sub-menu">
        <ul>
            <?php $has_sub = ''; ?>
            <?php $__currentLoopData = $Categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php $active_cat = ""; ?>
            <?php if($CurrentCategory!="none"): ?>
            <?php if(!empty($CurrentCategory)): ?>
            <?php if($Category->id == $CurrentCategory->id): ?>
            <?php $active_cat = "active"; ?>
            <?php endif; ?>
            <?php if(count($Category->fatherSections)>0): ?>
            <?php $has_sub = 'has-sub'; ?>
            <?php else: ?> 
            <?php $has_sub = ''; ?>
            <?php endif; ?>


            <?php endif; ?>
            <?php endif; ?>
            <?php
            $ccount = $category_and_topics_count[$Category->id];
            if ($Category->$slug_var != "" && Helper::GeneralWebmasterSettings("links_status")) {
                if (trans('backLang.code') != env('DEFAULT_LANGUAGE')) {
                    $Category_link_url = url(trans('backLang.code') . "/" . $Category->$slug_var);
                } else {
                    $Category_link_url = url($Category->$slug_var);
                }
            } else {
               
                    $Category_link_url = route('FrontendProductsByCat', ["cat" => $Category->id]);
                
            }
            ?>
            <li  class="<?php echo e($active_cat); ?> <?php echo e($has_sub); ?>">
                <?php if($Category->icon !=""): ?>
                <i class="fa <?php echo e($Category->icon); ?>"></i> &nbsp;
                <?php endif; ?>
                <a  href="<?php echo e($Category_link_url); ?>"><?php echo e($Category->$category_title_var); ?> (<?php echo e($ccount); ?>)</a>


                <?php if($has_sub != ''): ?>
                <ul>
                <?php $__currentLoopData = $Category->fatherSections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $MnuCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $active_cat = ""; ?>
                <?php if($CurrentCategory!="none"): ?>
                <?php if(!empty($CurrentCategory)): ?>
                <?php if($MnuCategory->id == $CurrentCategory->id): ?>
                <?php $active_cat = "class=active"; ?>
                <?php endif; ?>
                <?php endif; ?>
                <?php endif; ?>
                <?php
                $ccount = $category_and_topics_count[$MnuCategory->id];
                if ($MnuCategory->$slug_var != "" && Helper::GeneralWebmasterSettings("links_status")) {
                    if (trans('backLang.code') != env('DEFAULT_LANGUAGE')) {
                        $SubCategory_link_url = url(trans('backLang.code') . "/" . $MnuCategory->$slug_var);
                    } else {
                        $SubCategory_link_url = url($MnuCategory->$slug_var);
                    }
                } else {
                    $SubCategory_link_url = route('FrontendProductsByCat', [ "cat" => $MnuCategory->id]);
                }
                ?>
                
                <li style="display: -webkit-inline-box;">
                    <?php if($MnuCategory->icon !=""): ?>
                    <i class="fa <?php echo e($MnuCategory->icon); ?>"></i> &nbsp;
                    <?php endif; ?>
                    <a class="<?php echo e($active_cat); ?>"  href="<?php echo e($SubCategory_link_url); ?>"><?php echo e($MnuCategory->$category_title_var); ?>(<?php echo e($ccount); ?>)</a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </ul>
                <?php endif; ?>
                </li>



                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                   
                   
                </ul>
            </div>
            <!-- Category Sub Menu Area End Here -->
        </div>


        <?php endif; ?>


    </div>