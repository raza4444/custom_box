<?php $__env->startSection('content'); ?>
<div class="body-wrapper" id="app">

    <!-- Begin Slider With Banner Area -->
    <div class="slider-with-banner pt-30">
        <div class="container">
            <div class="row">
                <!-- Begin Slider Area -->
                <?php echo $__env->make('frontEnd.pages.home.container.slider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <!-- Slider Area End Here -->

            </div>
        </div>
    </div>
    <!-- Slider With Banner Area End Here -->
    <!-- Begin FB's customer Support Area -->

    <?php echo $__env->make('frontEnd.pages.home.container.customer-support-top', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php
                $title_var = "title_" . trans('backLang.boxCode');
                $title_var2 = "title_" . trans('backLang.boxCodeOther');
                $details_var = "details_" . trans('backLang.boxCode');
                $details_var2 = "details_" . trans('backLang.boxCodeOther');
                $slug_var = "seo_url_slug_" . trans('backLang.boxCode');
                $slug_var2 = "seo_url_slug_" . trans('backLang.boxCodeOther');
                $i = 0;
                ?>
    <!-- FB's customer Support Area End Here -->
    <!-- Begin FB's Product With Banner Area -->
    <div class="fb-product_with_banner pb-60">
        <div class="container">
            <div class="fb-section_title">
                <h2>Latest</h2>
            </div>
            <div class="row no-gutters">
                <!-- Begin FB's Banner Area -->
                <div class="col-xl-3 col-lg-4 col-md-5">
                    <div class="fb-banner fb-img-hover-effect">
                        <a href="#">
                            <img src="<?php echo e(URL::asset('front_end/images/banner/1_3.jpg')); ?>" alt="FB'S Banner">
                        </a>
                    </div>
                </div>
                <!-- FB's Banner Area End Here -->
                <!-- Begin FB's Product Wrap Area -->
                <div class="col-xl-9 col-lg-8 col-md-7">
                    <div class="fb-product_wrap bg-white">
                        <div class="fb-product_active owl-carousel">
                            <!-- Begin Sigle Product Area -->
                           
                           <?php $__currentLoopData = $latestProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                    if ($Topic->$title_var != "") {
                                        $title = $Topic->$title_var;
                                    } else {
                                        $title = $Topic->$title_var2;
                                    }
                                    if ($Topic->$details_var != "") {
                                        $details = $details_var;
                                    } else {
                                        $details = $details_var2;
                                    }
                                    $section = "";
                                    try {
                                        if ($Topic->section->$title_var != "") {
                                            $section = $Topic->section->$title_var;
                                        } else {
                                            $section = $Topic->section->$title_var2;
                                        }
                                    } catch (Exception $e) {
                                        $section = "";
                                    }

                                    // set row div
                                    if (($i == 1 && count($Categories) > 0) || ($i == 2 && count($Categories) == 0)) {
                                        $i = 0;
                                        echo "</div><div class='row'>";
                                    }
                                    if ($Topic->$slug_var != "" && Helper::GeneralWebmasterSettings("links_status")) {
                                        if (trans('backLang.code') != env('DEFAULT_LANGUAGE')) {
                                            $topic_link_url = url(trans('backLang.code') . "/" . $Topic->$slug_var);
                                        } else {
                                            $topic_link_url = url($Topic->$slug_var);
                                        }
                                    } else {
                                        $topic_link_url = route('FrontendProduct', ["id" => $Topic->id]);
                                    }
                                    ?> 
                            <div class="single-product">
                                <!-- Begin Product Image Area -->
                                <div class="product-img">
                                    <a href="<?php echo e($topic_link_url); ?>">
                                        <?php if($Topic->photo_file !=""): ?>
                                        <img class="primary-img" src="<?php echo e(URL::to('uploads/topics/'.$Topic->photo_file)); ?>" alt="FB'S Prduct">
                                        <?php endif; ?>
                                    </a>
                                    <div class="countersection">
                                        <div class="fb-countdown"></div>
                                    </div>
                                </div>
                                <!-- Product Image Area End Here -->
                                <!-- Begin Product Content Area -->
                                <div class="product-content">
                                    <h2 class="product-name">
                                        <a href="single-product">Printed Dress</a>
                                    </h2>
                                    <div class="rating-box">
                                        <ul class="rating">
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                        </ul>
                                    </div>
                                    <div class="price-box">
                                        <span class="new-price">$46.91</span>
                                        <span class="old-price">$50.99</span>
                                    </div>
                                    <div class="product-action">
                                        <ul class="product-action-link">
                                            <li class="shopping-cart_link"><a href="shopping-cart.html" title="Shopping Cart"><i class="ion-bag"></i></a></li>
                                            <li class="quick-view-btn"><a href="#" title="Quick View" data-toggle="modal" data-target="#exampleModalCenter"><i class="ion-eye"></i></a></li>
                                            <li class="single-product_link"><a href="product-details.html" title="Single Product"><i class="ion-link"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- Product Content Area End Here -->
                            </div>
                            <!-- Sigle Product Area End Here -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <!-- Begin Sigle Product Area -->
                            <div class="single-product">
                                <!-- Begin Product Image Area -->
                                <div class="product-img">
                                    <a href="product-details.html">
                                        <img class="primary-img" src="<?php echo e(URL::asset('front_end/images/product/2_1.jpg')); ?>" alt="FB'S Prduct">
                                        <img class="secondary-img" src="<?php echo e(URL::asset('front_end/images/product/2_2.jpg')); ?>" alt="FB'S Prduct">
                                    </a>
                                    <div class="sticker"><span>New</span></div>
                                    <div class="sticker-2"><span>-10%</span></div>
                                    <div class="countersection">
                                        <div class="fb-countdown"></div>
                                    </div>
                                </div>
                                <!-- Product Image Area End Here -->
                                <!-- Begin Product Content Area -->
                                <div class="product-content">
                                    <h2 class="product-name">
                                        <a href="single-product">Printed Dress</a>
                                    </h2>
                                    <div class="rating-box">
                                        <ul class="rating">
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                        </ul>
                                    </div>
                                    <div class="price-box">
                                        <span class="new-price">$46.91</span>
                                        <span class="old-price">$50.99</span>
                                    </div>
                                    <div class="product-action">
                                        <ul class="product-action-link">
                                            <li class="shopping-cart_link"><a href="shopping-cart.html" title="Shopping Cart"><i class="ion-bag"></i></a></li>
                                            <li class="quick-view-btn"><a href="#" title="Quick View" data-toggle="modal" data-target="#exampleModalCenter"><i class="ion-eye"></i></a></li>
                                            <li class="single-product_link"><a href="product-details.html" title="Single Product"><i class="ion-link"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- Product Content Area End Here -->
                            </div>
                            <!-- Sigle Product Area End Here -->
                            <!-- Begin Sigle Product Area -->
                            <div class="single-product">
                                <!-- Begin Product Image Area -->
                                <div class="product-img">
                                    <a href="product-details.html">
                                        <img class="primary-img" src="<?php echo e(URL::asset('front_end/images/product/3_1.jpg')); ?>" alt="FB'S Prduct">
                                        <img class="secondary-img" src="<?php echo e(URL::asset('front_end/images/product/3_2.jpg')); ?>" alt="FB'S Prduct">
                                    </a>
                                    <div class="sticker"><span>New</span></div>
                                    <div class="sticker-2"><span>-10%</span></div>
                                    <div class="countersection">
                                        <div class="fb-countdown"></div>
                                    </div>
                                </div>
                                <!-- Product Image Area End Here -->
                                <!-- Begin Product Content Area -->
                                <div class="product-content">
                                    <h2 class="product-name">
                                        <a href="single-product">Printed Dress</a>
                                    </h2>
                                    <div class="rating-box">
                                        <ul class="rating">
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                        </ul>
                                    </div>
                                    <div class="price-box">
                                        <span class="new-price">$46.91</span>
                                        <span class="old-price">$50.99</span>
                                    </div>
                                    <div class="product-action">
                                        <ul class="product-action-link">
                                            <li class="shopping-cart_link"><a href="shopping-cart.html" title="Shopping Cart"><i class="ion-bag"></i></a></li>
                                            <li class="quick-view-btn"><a href="#" title="Quick View" data-toggle="modal" data-target="#exampleModalCenter"><i class="ion-eye"></i></a></li>
                                            <li class="single-product_link"><a href="product-details.html" title="Single Product"><i class="ion-link"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- Product Content Area End Here -->
                            </div>
                            <!-- Sigle Product Area End Here -->
                            <!-- Begin Sigle Product Area -->
                            <div class="single-product">
                                <!-- Begin Product Image Area -->
                                <div class="product-img">
                                    <a href="product-details.html">
                                        <img class="primary-img" src="assets/images/product/4_1.jpg" alt="FB'S Prduct">
                                        <img class="secondary-img" src="assets/images/product/4_2.jpg" alt="FB'S Prduct">
                                    </a>
                                    <div class="sticker"><span>New</span></div>
                                    <div class="sticker-2"><span>-10%</span></div>
                                    <div class="countersection">
                                        <div class="fb-countdown"></div>
                                    </div>
                                </div>
                                <!-- Product Image Area End Here -->
                                <!-- Begin Product Content Area -->
                                <div class="product-content">
                                    <h2 class="product-name">
                                        <a href="single-product">Printed Dress</a>
                                    </h2>
                                    <div class="rating-box">
                                        <ul class="rating">
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                        </ul>
                                    </div>
                                    <div class="price-box">
                                        <span class="new-price">$46.91</span>
                                        <span class="old-price">$50.99</span>
                                    </div>
                                    <div class="product-action">
                                        <ul class="product-action-link">
                                            <li class="shopping-cart_link"><a href="shopping-cart.html" title="Shopping Cart"><i class="ion-bag"></i></a></li>
                                            <li class="quick-view-btn"><a href="#" title="Quick View" data-toggle="modal" data-target="#exampleModalCenter"><i class="ion-eye"></i></a></li>
                                            <li class="single-product_link"><a href="product-details.html" title="Single Product"><i class="ion-link"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- Product Content Area End Here -->
                            </div>
                            <!-- Sigle Product Area End Here -->
                            <!-- Begin Sigle Product Area -->
                            <div class="single-product">
                                <!-- Begin Product Image Area -->
                                <div class="product-img">
                                    <a href="product-details.html">
                                        <img class="primary-img" src="assets/images/product/5_1.jpg" alt="FB'S Prduct">
                                        <img class="secondary-img" src="assets/images/product/5_2.jpg" alt="FB'S Prduct">
                                    </a>
                                    <div class="sticker"><span>New</span></div>
                                    <div class="sticker-2"><span>-10%</span></div>
                                    <div class="countersection">
                                        <div class="fb-countdown"></div>
                                    </div>
                                </div>
                                <!-- Product Image Area End Here -->
                                <!-- Begin Product Content Area -->
                                <div class="product-content">
                                    <h2 class="product-name">
                                        <a href="single-product">Printed Dress</a>
                                    </h2>
                                    <div class="rating-box">
                                        <ul class="rating">
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                        </ul>
                                    </div>
                                    <div class="price-box">
                                        <span class="new-price">$46.91</span>
                                        <span class="old-price">$50.99</span>
                                    </div>
                                    <div class="product-action">
                                        <ul class="product-action-link">
                                            <li class="shopping-cart_link"><a href="shopping-cart.html" title="Shopping Cart"><i class="ion-bag"></i></a></li>
                                            <li class="quick-view-btn"><a href="#" title="Quick View" data-toggle="modal" data-target="#exampleModalCenter"><i class="ion-eye"></i></a></li>
                                            <li class="single-product_link"><a href="product-details.html" title="Single Product"><i class="ion-link"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- Product Content Area End Here -->
                            </div>
                            <!-- Sigle Product Area End Here -->
                        </div>
                    </div>
                </div>
                <!-- FB's Product Wrap Area End Here -->
            </div>
        </div>
    </div>
    <!-- FB's Product Area End Here -->
    <!-- Begin FB's Banner Wrap Area -->
    <div class="fb-banner_wrap">
        <div class="container">
            <div class="row">
                <!-- Begin FB's Banner Area -->
                <div class="col-lg-12">
                    <div class="fb-banner fb-img-hover-effect pb-sm-30 pb-xs-30 our-procedure">
                        <br/><br/>


                        <div class="row"> 

                            <div class="col-lg-12"> <h1 style="font-size: 50px; color: #F98100;">
                                <span style="display: block; text-align: center;"> Our <strong>Procedure</strong>
                                </span></h1> 

                                <p>
                                  <span style="display: block; text-align: center; font-size: 20px; color: #fff;">Our Online Procedure With 24/7 Customer Service Provides you a Convenient way
                                        <br> to help Process your Order Faster and more Reliable.
                                    </span></p> 
                                </div> 
                            </div>

                            

<div class="row" style="margin-top: 4em;"> 

<div class="col-lg-1 no-div">
</div> 

<div class="col-xs-12 col-sm-6 col-md-2 text-center our-procedure-img-div"> <span><img class="img-responsive lazy" alt="quality.png" src="<?php echo e(URL::asset('front_end/images/procedure/get-a-label.png')); ?>" style="display: block;"></span> 
<br>     <img class="img-responsive lazy" alt="quote.png" src="<?php echo e(URL::asset('front_end//images/procedure/quote.png')); ?>" style="display: block;"> 
</div> 

<div class="col-xs-12 col-sm-6 col-md-2 text-center our-procedure-img-div"> <span><img class="img-responsive lazy" alt="quality.png" src="<?php echo e(URL::asset('front_end/images/procedure/aprove-art-work-label.png')); ?>" style="display: block;"></span> 
<br>  <img class="img-responsive lazy" alt="art.png" src="<?php echo e(URL::asset('front_end/images/procedure/art.png')); ?>" style="display: block;"> 
</div> 

<div class="col-xs-12 col-sm-6 col-md-2 text-center our-procedure-img-div"> <span><img class="img-responsive lazy" alt="quality.png" src="<?php echo e(URL::asset('front_end/images/procedure/production-label.png')); ?>" style="display: block;"></span> 
<br>    <img class="img-responsive lazy" alt="production.png" src="<?php echo e(URL::asset('front_end//images/procedure/production.png')); ?>" style="display: block;"> 
</div> 

<div class="col-xs-12 col-sm-6 col-md-2 text-center our-procedure-img-div"> <span><img class="img-responsive lazy" alt="quality.png" src="<?php echo e(URL::asset('front_end//images/procedure/quality-label.png')); ?>" style="display: block;"></span> 
<br>  <img class="img-responsive lazy" alt="quality.png" src="<?php echo e(URL::asset('front_end//images/procedure/quality.png')); ?>" style="display: block;"> 
</div> 

<div class="col-xs-12 col-sm-6 col-md-2 text-center our-procedure-img-div"> <span><img class="img-responsive lazy" alt="quality.png" src="<?php echo e(URL::asset('front_end/images/procedure/shipping-label.png')); ?>" style="display: block;"></span> 
<br> <img class="img-responsive lazy" alt="shipment.png" src="<?php echo e(URL::asset('front_end//images/procedure/shipment.png')); ?>" style="display: block;"> 
</div> 

<div class="col-xs-1 no-div">
</div> 
</div>

                        </div>
                    </div>
                    <!-- FB's Banner Area End Here -->
                    <!-- Begin FB's Banner Area -->

                    <!-- FB's Banner Area End Here -->
                </div>
            </div>
        </div>
        <!-- FB's Banner Wrap Area End Here -->
        <!-- Begin FB's Banner With List Product Area -->
        <div class="fb-banner_with_list-product cookware-product pt-60 pb-60">
            <div class="container">
                <div class="fb-product_list_nav">
                    <div class="row no-gutters">
                        <div class="col-xl-3 col-lg-4 col-md-5">
                            <div class="fb-section_title-2">
                                <h2>Cookware</h2>
                            </div>
                            <!-- Begin FB's Banner Area -->
                            <div class="fb-banner fb-img-hover-effect">
                                <a href="#">
                                    <img src="assets/images/banner/1_6.jpg" alt="FB'S Banner">
                                </a>
                            </div>
                            <!-- FB's Banner Area End Here -->
                        </div>
                        <div class="col-xl-9 col-lg-8 col-md-7">
                            <div class="btn-group">
                                <button class="subcategories-trigger"><i class="fa fa-bars"></i></button>
                                <ul class="subcategories-list">
                                 <li><a href="shop-left-sidebar.html" target="_blank">Cookware Brands</a></li>
                                 <li><a href="shop-left-sidebar.html" target="_blank">Cookware Sets</a></li>
                                 <li><a href="shop-left-sidebar.html" target="_blank">Individual Cookware</a></li>
                                 <li><a href="shop-left-sidebar.html" target="_blank">Enamel Cookware</a></li>
                             </ul>
                             <!-- Begin FB's List Product Menu Area -->
                             <ul class="list-product_menu">
                                <li><a href="shop-left-sidebar.html" target="_blank">Cookware Brands</a></li>
                                <li><a href="shop-left-sidebar.html" target="_blank">Cookware Sets</a></li>
                                <li><a href="shop-left-sidebar.html" target="_blank">Individual Cookware</a></li>
                                <li><a href="shop-left-sidebar.html" target="_blank">Enamel Cookware</a></li>
                            </ul>
                            <!-- FB's List Product Menu Area End Here -->
                        </div>
                        <!-- Begin FB's List Product Area -->
                        <div class="fb-list_product">
                            <div class="fb-list_product_active owl-carousel">
                                <div class="row no-gutters">
                                    <!-- Begin Sigle Product Area -->
                                    <div class="single-product list-single_product">
                                        <!-- Begin Product Image Area -->
                                        <div class="product-img list-product_img">
                                            <a href="product-details.html">
                                                <img class="primary-img" src="assets/images/product/6_1.jpg" alt="FB'S Prduct">
                                                <img class="secondary-img" src="assets/images/product/6_2.jpg" alt="FB'S Prduct">
                                            </a>
                                            <div class="sticker"><span>New</span></div>
                                        </div>
                                        <!-- Product Image Area End Here -->
                                        <!-- Begin Product Content Area -->
                                        <div class="product-content list-product_content">
                                            <h2 class="product-name">
                                                <a href="single-product">Printed Dress</a>
                                            </h2>
                                            <div class="rating-box">
                                                <ul class="rating">
                                                    <li><i class="fa fa-star"></i></li>
                                                    <li><i class="fa fa-star"></i></li>
                                                    <li><i class="fa fa-star"></i></li>
                                                    <li><i class="fa fa-star"></i></li>
                                                    <li><i class="fa fa-star"></i></li>
                                                </ul>
                                            </div>
                                            <div class="price-box">
                                                <span class="new-price">$46.91</span>
                                            </div>
                                            <div class="product-action list-product_action">
                                                <ul class="product-action-link">
                                                    <li class="shopping-cart_link"><a href="shopping-cart.html" title="Shopping Cart"><i class="ion-bag"></i></a></li>
                                                    <li class="quick-view-btn"><a href="#" title="Quick View" data-toggle="modal" data-target="#exampleModalCenter"><i class="ion-eye"></i></a></li>
                                                    <li class="single-product_link"><a href="product-details.html" title="Single Product"><i class="ion-link"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <!-- Product Content Area End Here -->
                                    </div>
                                    <!-- Sigle Product Area End Here -->
                                    <!-- Begin Sigle Product Area -->
                                    <div class="single-product list-single_product">
                                        <!-- Begin Product Image Area -->
                                        <div class="product-img list-product_img">
                                            <a href="product-details.html">
                                                <img class="primary-img" src="assets/images/product/7_1.jpg" alt="FB'S Prduct">
                                                <img class="secondary-img" src="assets/images/product/7_2.jpg" alt="FB'S Prduct">
                                            </a>
                                            <div class="sticker"><span>New</span></div>
                                        </div>
                                        <!-- Product Image Area End Here -->
                                        <!-- Begin Product Content Area -->
                                        <div class="product-content list-product_content">
                                            <h2 class="product-name">
                                                <a href="single-product">Printed Dress</a>
                                            </h2>
                                            <div class="rating-box">
                                                <ul class="rating">
                                                    <li class="no-star"><i class="fa fa-star"></i></li>
                                                    <li class="no-star"><i class="fa fa-star"></i></li>
                                                    <li class="no-star"><i class="fa fa-star"></i></li>
                                                    <li class="no-star"><i class="fa fa-star"></i></li>
                                                    <li class="no-star"><i class="fa fa-star"></i></li>
                                                </ul>
                                            </div>
                                            <div class="price-box">
                                                <span class="new-price">$46.91</span>
                                            </div>
                                            <div class="product-action list-product_action">
                                                <ul class="product-action-link">
                                                    <li class="shopping-cart_link"><a href="shopping-cart.html" title="Shopping Cart"><i class="ion-bag"></i></a></li>
                                                    <li class="quick-view-btn"><a href="#" title="Quick View" data-toggle="modal" data-target="#exampleModalCenter"><i class="ion-eye"></i></a></li>
                                                    <li class="single-product_link"><a href="product-details.html" title="Single Product"><i class="ion-link"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <!-- Product Content Area End Here -->
                                    </div>
                                    <!-- Sigle Product Area End Here -->
                                </div>
                                <div class="row no-gutters">
                                    <!-- Begin Sigle Product Area -->
                                    <div class="single-product list-single_product">
                                        <!-- Begin Product Image Area -->
                                        <div class="product-img list-product_img">
                                            <a href="product-details.html">
                                                <img class="primary-img" src="assets/images/product/8_1.jpg" alt="FB'S Prduct">
                                                <img class="secondary-img" src="assets/images/product/8_2.jpg" alt="FB'S Prduct">
                                            </a>
                                            <div class="sticker"><span>New</span></div>
                                        </div>
                                        <!-- Product Image Area End Here -->
                                        <!-- Begin Product Content Area -->
                                        <div class="product-content list-product_content">
                                            <h2 class="product-name">
                                                <a href="single-product">Printed Dress</a>
                                            </h2>
                                            <div class="rating-box">
                                                <ul class="rating">
                                                    <li class="no-star"><i class="fa fa-star"></i></li>
                                                    <li class="no-star"><i class="fa fa-star"></i></li>
                                                    <li class="no-star"><i class="fa fa-star"></i></li>
                                                    <li class="no-star"><i class="fa fa-star"></i></li>
                                                    <li class="no-star"><i class="fa fa-star"></i></li>
                                                </ul>
                                            </div>
                                            <div class="price-box">
                                                <span class="new-price">$46.91</span>
                                            </div>
                                            <div class="product-action list-product_action">
                                                <ul class="product-action-link">
                                                    <li class="shopping-cart_link"><a href="shopping-cart.html" title="Shopping Cart"><i class="ion-bag"></i></a></li>
                                                    <li class="quick-view-btn"><a href="#" title="Quick View" data-toggle="modal" data-target="#exampleModalCenter"><i class="ion-eye"></i></a></li>
                                                    <li class="single-product_link"><a href="product-details.html" title="Single Product"><i class="ion-link"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <!-- Product Content Area End Here -->
                                    </div>
                                    <!-- Sigle Product Area End Here -->
                                    <!-- Begin Sigle Product Area -->
                                    <div class="single-product list-single_product">
                                        <!-- Begin Product Image Area -->
                                        <div class="product-img list-product_img">
                                            <a href="product-details.html">
                                                <img class="primary-img" src="assets/images/product/9.jpg" alt="FB'S Prduct">
                                            </a>
                                            <div class="sticker"><span>New</span></div>
                                        </div>
                                        <!-- Product Image Area End Here -->
                                        <!-- Begin Product Content Area -->
                                        <div class="product-content list-product_content">
                                            <h2 class="product-name">
                                                <a href="single-product">Printed Dress</a>
                                            </h2>
                                            <div class="rating-box">
                                                <ul class="rating">
                                                    <li class="no-star"><i class="fa fa-star"></i></li>
                                                    <li class="no-star"><i class="fa fa-star"></i></li>
                                                    <li class="no-star"><i class="fa fa-star"></i></li>
                                                    <li class="no-star"><i class="fa fa-star"></i></li>
                                                    <li class="no-star"><i class="fa fa-star"></i></li>
                                                </ul>
                                            </div>
                                            <div class="price-box">
                                                <span class="new-price">$46.91</span>
                                            </div>
                                            <div class="product-action list-product_action">
                                                <ul class="product-action-link">
                                                    <li class="shopping-cart_link"><a href="shopping-cart.html" title="Shopping Cart"><i class="ion-bag"></i></a></li>
                                                    <li class="quick-view-btn"><a href="#" title="Quick View" data-toggle="modal" data-target="#exampleModalCenter"><i class="ion-eye"></i></a></li>
                                                    <li class="single-product_link"><a href="product-details.html" title="Single Product"><i class="ion-link"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <!-- Product Content Area End Here -->
                                    </div>
                                    <!-- Sigle Product Area End Here -->
                                </div>
                                <div class="row no-gutters">
                                    <!-- Begin Sigle Product Area -->
                                    <div class="single-product list-single_product">
                                        <!-- Begin Product Image Area -->
                                        <div class="product-img list-product_img">
                                            <a href="product-details.html">
                                                <img class="primary-img" src="assets/images/product/8_1.jpg" alt="FB'S Prduct">
                                                <img class="secondary-img" src="assets/images/product/8_2.jpg" alt="FB'S Prduct">
                                            </a>
                                            <div class="sticker"><span>New</span></div>
                                        </div>
                                        <!-- Product Image Area End Here -->
                                        <!-- Begin Product Content Area -->
                                        <div class="product-content list-product_content">
                                            <h2 class="product-name">
                                                <a href="single-product">Printed Dress</a>
                                            </h2>
                                            <div class="rating-box">
                                                <ul class="rating">
                                                    <li class="no-star"><i class="fa fa-star"></i></li>
                                                    <li class="no-star"><i class="fa fa-star"></i></li>
                                                    <li class="no-star"><i class="fa fa-star"></i></li>
                                                    <li class="no-star"><i class="fa fa-star"></i></li>
                                                    <li class="no-star"><i class="fa fa-star"></i></li>
                                                </ul>
                                            </div>
                                            <div class="price-box">
                                                <span class="new-price">$46.91</span>
                                            </div>
                                            <div class="product-action list-product_action">
                                                <ul class="product-action-link">
                                                    <li class="shopping-cart_link"><a href="shopping-cart.html" title="Shopping Cart"><i class="ion-bag"></i></a></li>
                                                    <li class="quick-view-btn"><a href="#" title="Quick View" data-toggle="modal" data-target="#exampleModalCenter"><i class="ion-eye"></i></a></li>
                                                    <li class="single-product_link"><a href="product-details.html" title="Single Product"><i class="ion-link"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <!-- Product Content Area End Here -->
                                    </div>
                                    <!-- Sigle Product Area End Here -->
                                    <!-- Begin Sigle Product Area -->
                                    <div class="single-product list-single_product">
                                        <!-- Begin Product Image Area -->
                                        <div class="product-img list-product_img">
                                            <a href="product-details.html">
                                                <img class="primary-img" src="assets/images/product/9.jpg" alt="FB'S Prduct">
                                            </a>
                                            <div class="sticker"><span>New</span></div>
                                        </div>
                                        <!-- Product Image Area End Here -->
                                        <!-- Begin Product Content Area -->
                                        <div class="product-content list-product_content">
                                            <h2 class="product-name">
                                                <a href="single-product">Printed Dress</a>
                                            </h2>
                                            <div class="rating-box">
                                                <ul class="rating">
                                                    <li class="no-star"><i class="fa fa-star"></i></li>
                                                    <li class="no-star"><i class="fa fa-star"></i></li>
                                                    <li class="no-star"><i class="fa fa-star"></i></li>
                                                    <li class="no-star"><i class="fa fa-star"></i></li>
                                                    <li class="no-star"><i class="fa fa-star"></i></li>
                                                </ul>
                                            </div>
                                            <div class="price-box">
                                                <span class="new-price">$46.91</span>
                                            </div>
                                            <div class="product-action list-product_action">
                                                <ul class="product-action-link">
                                                    <li class="shopping-cart_link"><a href="shopping-cart.html" title="Shopping Cart"><i class="ion-bag"></i></a></li>
                                                    <li class="quick-view-btn"><a href="#" title="Quick View" data-toggle="modal" data-target="#exampleModalCenter"><i class="ion-eye"></i></a></li>
                                                    <li class="single-product_link"><a href="product-details.html" title="Single Product"><i class="ion-link"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <!-- Product Content Area End Here -->
                                    </div>
                                    <!-- Sigle Product Area End Here -->
                                </div>
                                <div class="row no-gutters">
                                    <!-- Begin Sigle Product Area -->
                                    <div class="single-product list-single_product">
                                        <!-- Begin Product Image Area -->
                                        <div class="product-img list-product_img">
                                            <a href="product-details.html">
                                                <img class="primary-img" src="assets/images/product/8_1.jpg" alt="FB'S Prduct">
                                                <img class="secondary-img" src="assets/images/product/8_2.jpg" alt="FB'S Prduct">
                                            </a>
                                            <div class="sticker"><span>New</span></div>
                                        </div>
                                        <!-- Product Image Area End Here -->
                                        <!-- Begin Product Content Area -->
                                        <div class="product-content list-product_content">
                                            <h2 class="product-name">
                                                <a href="single-product">Printed Dress</a>
                                            </h2>
                                            <div class="rating-box">
                                                <ul class="rating">
                                                    <li class="no-star"><i class="fa fa-star"></i></li>
                                                    <li class="no-star"><i class="fa fa-star"></i></li>
                                                    <li class="no-star"><i class="fa fa-star"></i></li>
                                                    <li class="no-star"><i class="fa fa-star"></i></li>
                                                    <li class="no-star"><i class="fa fa-star"></i></li>
                                                </ul>
                                            </div>
                                            <div class="price-box">
                                                <span class="new-price">$46.91</span>
                                            </div>
                                            <div class="product-action list-product_action">
                                                <ul class="product-action-link">
                                                    <li class="shopping-cart_link"><a href="shopping-cart.html" title="Shopping Cart"><i class="ion-bag"></i></a></li>
                                                    <li class="quick-view-btn"><a href="#" title="Quick View" data-toggle="modal" data-target="#exampleModalCenter"><i class="ion-eye"></i></a></li>
                                                    <li class="single-product_link"><a href="product-details.html" title="Single Product"><i class="ion-link"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <!-- Product Content Area End Here -->
                                    </div>
                                    <!-- Sigle Product Area End Here -->
                                    <!-- Begin Sigle Product Area -->
                                    <div class="single-product list-single_product">
                                        <!-- Begin Product Image Area -->
                                        <div class="product-img list-product_img">
                                            <a href="product-details.html">
                                                <img class="primary-img" src="assets/images/product/9.jpg" alt="FB'S Prduct">
                                            </a>
                                            <div class="sticker"><span>New</span></div>
                                        </div>
                                        <!-- Product Image Area End Here -->
                                        <!-- Begin Product Content Area -->
                                        <div class="product-content list-product_content">
                                            <h2 class="product-name">
                                                <a href="single-product">Printed Dress</a>
                                            </h2>
                                            <div class="rating-box">
                                                <ul class="rating">
                                                    <li class="no-star"><i class="fa fa-star"></i></li>
                                                    <li class="no-star"><i class="fa fa-star"></i></li>
                                                    <li class="no-star"><i class="fa fa-star"></i></li>
                                                    <li class="no-star"><i class="fa fa-star"></i></li>
                                                    <li class="no-star"><i class="fa fa-star"></i></li>
                                                </ul>
                                            </div>
                                            <div class="price-box">
                                                <span class="new-price">$46.91</span>
                                            </div>
                                            <div class="product-action list-product_action">
                                                <ul class="product-action-link">
                                                    <li class="shopping-cart_link"><a href="shopping-cart.html" title="Shopping Cart"><i class="ion-bag"></i></a></li>
                                                    <li class="quick-view-btn"><a href="#" title="Quick View" data-toggle="modal" data-target="#exampleModalCenter"><i class="ion-eye"></i></a></li>
                                                    <li class="single-product_link"><a href="product-details.html" title="Single Product"><i class="ion-link"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <!-- Product Content Area End Here -->
                                    </div>
                                    <!-- Sigle Product Area End Here -->
                                </div>
                            </div>
                        </div>
                        <!-- FB's List Product Area End Here -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- FB's Banner With List Product Area End Here -->
    <!-- Begin FB's Banner With List Product Area -->
    <div class="fb-banner_with_list-product large-appliances_product pb-60">
        <div class="container">
            <div class="fb-product_list_nav">
                <div class="row no-gutters">
                    <div class="col-xl-3 col-lg-4 col-md-5">
                        <div class="fb-section_title-2">
                            <h2>Large Appliances</h2>
                        </div>
                        <!-- Begin FB's Banner Area -->
                        <div class="fb-banner fb-img-hover-effect">
                            <a href="#">
                                <img src="assets/images/banner/1_7.jpg" alt="FB'S Banner">
                            </a>
                        </div>
                        <!-- FB's Banner Area End Here -->
                    </div>
                    <div class="col-xl-9 col-lg-8 col-md-7">
                        <div class="btn-group">
                            <button class="subcategories-trigger"><i class="fa fa-bars"></i></button>
                            <ul class="subcategories-list">
                             <li><a href="shop-left-sidebar.html" target="_blank">Armchairs</a></li>
                             <li><a href="shop-left-sidebar.html" target="_blank">Bunk Bed</a></li>
                             <li><a href="shop-left-sidebar.html" target="_blank">Mattress</a></li>
                             <li><a href="shop-left-sidebar.html" target="_blank">Sideboard</a></li>
                         </ul>
                         <!-- Begin FB's List Product Menu Area -->
                         <ul class="list-product_menu">
                            <li><a href="shop-left-sidebar.html" target="_blank">Armchairs</a></li>
                            <li><a href="shop-left-sidebar.html" target="_blank">Bunk Bed</a></li>
                            <li><a href="shop-left-sidebar.html" target="_blank">Mattress</a></li>
                            <li><a href="shop-left-sidebar.html" target="_blank">Sideboard</a></li>
                        </ul>
                        <!-- FB's List Product Menu Area End Here -->
                    </div>
                    <!-- Begin FB's List Product Area -->
                    <div class="fb-list_product">
                        <div class="fb-list_product_active owl-carousel">
                            <div class="row no-gutters">
                                <!-- Begin Sigle Product Area -->
                                <div class="single-product list-single_product">
                                    <!-- Begin Product Image Area -->
                                    <div class="product-img list-product_img">
                                        <a href="product-details.html">
                                            <img class="primary-img" src="assets/images/product/10.jpg" alt="FB'S Prduct">
                                        </a>
                                        <div class="sticker"><span>New</span></div>
                                    </div>
                                    <!-- Product Image Area End Here -->
                                    <!-- Begin Product Content Area -->
                                    <div class="product-content list-product_content">
                                        <h2 class="product-name">
                                            <a href="single-product">Printed Dress</a>
                                        </h2>
                                        <div class="rating-box">
                                            <ul class="rating">
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                            </ul>
                                        </div>
                                        <div class="price-box">
                                            <span class="new-price">$46.91</span>
                                        </div>
                                        <div class="product-action list-product_action">
                                            <ul class="product-action-link">
                                                <li class="shopping-cart_link"><a href="shopping-cart.html" title="Shopping Cart"><i class="ion-bag"></i></a></li>
                                                <li class="quick-view-btn"><a href="#" title="Quick View" data-toggle="modal" data-target="#exampleModalCenter"><i class="ion-eye"></i></a></li>
                                                <li class="single-product_link"><a href="product-details.html" title="Single Product"><i class="ion-link"></i></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <!-- Product Content Area End Here -->
                                </div>
                                <!-- Sigle Product Area End Here -->
                                <!-- Begin Sigle Product Area -->
                                <div class="single-product list-single_product">
                                    <!-- Begin Product Image Area -->
                                    <div class="product-img list-product_img">
                                        <a href="product-details.html">
                                            <img class="primary-img" src="assets/images/product/11.jpg" alt="FB'S Prduct">
                                        </a>
                                        <div class="sticker"><span>New</span></div>
                                    </div>
                                    <!-- Product Image Area End Here -->
                                    <!-- Begin Product Content Area -->
                                    <div class="product-content list-product_content">
                                        <h2 class="product-name">
                                            <a href="single-product">Printed Dress</a>
                                        </h2>
                                        <div class="rating-box">
                                            <ul class="rating">
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                            </ul>
                                        </div>
                                        <div class="price-box">
                                            <span class="new-price">$46.91</span>
                                        </div>
                                        <div class="product-action list-product_action">
                                            <ul class="product-action-link">
                                                <li class="shopping-cart_link"><a href="shopping-cart.html" title="Shopping Cart"><i class="ion-bag"></i></a></li>
                                                <li class="quick-view-btn"><a href="#" title="Quick View" data-toggle="modal" data-target="#exampleModalCenter"><i class="ion-eye"></i></a></li>
                                                <li class="single-product_link"><a href="product-details.html" title="Single Product"><i class="ion-link"></i></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <!-- Product Content Area End Here -->
                                </div>
                                <!-- Sigle Product Area End Here -->
                            </div>
                            <div class="row no-gutters">
                                <!-- Begin Sigle Product Area -->
                                <div class="single-product list-single_product">
                                    <!-- Begin Product Image Area -->
                                    <div class="product-img list-product_img">
                                        <a href="product-details.html">
                                            <img class="primary-img" src="assets/images/product/12_1.jpg" alt="FB'S Prduct">
                                            <img class="secondary-img" src="assets/images/product/12_2.jpg" alt="FB'S Prduct">
                                        </a>
                                        <div class="sticker"><span>New</span></div>
                                    </div>
                                    <!-- Product Image Area End Here -->
                                    <!-- Begin Product Content Area -->
                                    <div class="product-content list-product_content">
                                        <h2 class="product-name">
                                            <a href="single-product">Printed Dress</a>
                                        </h2>
                                        <div class="rating-box">
                                            <ul class="rating">
                                                <li class="no-star"><i class="fa fa-star"></i></li>
                                                <li class="no-star"><i class="fa fa-star"></i></li>
                                                <li class="no-star"><i class="fa fa-star"></i></li>
                                                <li class="no-star"><i class="fa fa-star"></i></li>
                                                <li class="no-star"><i class="fa fa-star"></i></li>
                                            </ul>
                                        </div>
                                        <div class="price-box">
                                            <span class="new-price">$46.91</span>
                                        </div>
                                        <div class="product-action list-product_action">
                                            <ul class="product-action-link">
                                                <li class="shopping-cart_link"><a href="shopping-cart.html" title="Shopping Cart"><i class="ion-bag"></i></a></li>
                                                <li class="quick-view-btn"><a href="#" title="Quick View" data-toggle="modal" data-target="#exampleModalCenter"><i class="ion-eye"></i></a></li>
                                                <li class="single-product_link"><a href="product-details.html" title="Single Product"><i class="ion-link"></i></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <!-- Product Content Area End Here -->
                                </div>
                                <!-- Sigle Product Area End Here -->
                                <!-- Begin Sigle Product Area -->
                                <div class="single-product list-single_product">
                                    <!-- Begin Product Image Area -->
                                    <div class="product-img list-product_img">
                                        <a href="product-details.html">
                                            <img class="primary-img" src="assets/images/product/9.jpg" alt="FB'S Prduct">
                                        </a>
                                        <div class="sticker"><span>New</span></div>
                                    </div>
                                    <!-- Product Image Area End Here -->
                                    <!-- Begin Product Content Area -->
                                    <div class="product-content list-product_content">
                                        <h2 class="product-name">
                                            <a href="single-product">Printed Dress</a>
                                        </h2>
                                        <div class="rating-box">
                                            <ul class="rating">
                                                <li class="no-star"><i class="fa fa-star"></i></li>
                                                <li class="no-star"><i class="fa fa-star"></i></li>
                                                <li class="no-star"><i class="fa fa-star"></i></li>
                                                <li class="no-star"><i class="fa fa-star"></i></li>
                                                <li class="no-star"><i class="fa fa-star"></i></li>
                                            </ul>
                                        </div>
                                        <div class="price-box">
                                            <span class="new-price">$46.91</span>
                                        </div>
                                        <div class="product-action list-product_action">
                                            <ul class="product-action-link">
                                                <li class="shopping-cart_link"><a href="shopping-cart.html" title="Shopping Cart"><i class="ion-bag"></i></a></li>
                                                <li class="quick-view-btn"><a href="#" title="Quick View" data-toggle="modal" data-target="#exampleModalCenter"><i class="ion-eye"></i></a></li>
                                                <li class="single-product_link"><a href="product-details.html" title="Single Product"><i class="ion-link"></i></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <!-- Product Content Area End Here -->
                                </div>
                                <!-- Sigle Product Area End Here -->
                            </div>
                            <div class="row no-gutters">
                                <!-- Begin Sigle Product Area -->
                                <div class="single-product list-single_product">
                                    <!-- Begin Product Image Area -->
                                    <div class="product-img list-product_img">
                                        <a href="product-details.html">
                                            <img class="primary-img" src="assets/images/product/10.jpg" alt="FB'S Prduct">
                                        </a>
                                        <div class="sticker"><span>New</span></div>
                                    </div>
                                    <!-- Product Image Area End Here -->
                                    <!-- Begin Product Content Area -->
                                    <div class="product-content list-product_content">
                                        <h2 class="product-name">
                                            <a href="single-product">Printed Dress</a>
                                        </h2>
                                        <div class="rating-box">
                                            <ul class="rating">
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                            </ul>
                                        </div>
                                        <div class="price-box">
                                            <span class="new-price">$46.91</span>
                                        </div>
                                        <div class="product-action list-product_action">
                                            <ul class="product-action-link">
                                                <li class="shopping-cart_link"><a href="shopping-cart.html" title="Shopping Cart"><i class="ion-bag"></i></a></li>
                                                <li class="quick-view-btn"><a href="#" title="Quick View" data-toggle="modal" data-target="#exampleModalCenter"><i class="ion-eye"></i></a></li>
                                                <li class="single-product_link"><a href="product-details.html" title="Single Product"><i class="ion-link"></i></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <!-- Product Content Area End Here -->
                                </div>
                                <!-- Sigle Product Area End Here -->
                                <!-- Begin Sigle Product Area -->
                                <div class="single-product list-single_product">
                                    <!-- Begin Product Image Area -->
                                    <div class="product-img list-product_img">
                                        <a href="product-details.html">
                                            <img class="primary-img" src="assets/images/product/11.jpg" alt="FB'S Prduct">
                                        </a>
                                        <div class="sticker"><span>New</span></div>
                                    </div>
                                    <!-- Product Image Area End Here -->
                                    <!-- Begin Product Content Area -->
                                    <div class="product-content list-product_content">
                                        <h2 class="product-name">
                                            <a href="single-product">Printed Dress</a>
                                        </h2>
                                        <div class="rating-box">
                                            <ul class="rating">
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                            </ul>
                                        </div>
                                        <div class="price-box">
                                            <span class="new-price">$46.91</span>
                                        </div>
                                        <div class="product-action list-product_action">
                                            <ul class="product-action-link">
                                                <li class="shopping-cart_link"><a href="shopping-cart.html" title="Shopping Cart"><i class="ion-bag"></i></a></li>
                                                <li class="quick-view-btn"><a href="#" title="Quick View" data-toggle="modal" data-target="#exampleModalCenter"><i class="ion-eye"></i></a></li>
                                                <li class="single-product_link"><a href="product-details.html" title="Single Product"><i class="ion-link"></i></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <!-- Product Content Area End Here -->
                                </div>
                                <!-- Sigle Product Area End Here -->
                            </div>
                            <div class="row no-gutters">
                                <!-- Begin Sigle Product Area -->
                                <div class="single-product list-single_product">
                                    <!-- Begin Product Image Area -->
                                    <div class="product-img list-product_img">
                                        <a href="product-details.html">
                                            <img class="primary-img" src="assets/images/product/12_1.jpg" alt="FB'S Prduct">
                                            <img class="secondary-img" src="assets/images/product/12_2.jpg" alt="FB'S Prduct">
                                        </a>
                                        <div class="sticker"><span>New</span></div>
                                    </div>
                                    <!-- Product Image Area End Here -->
                                    <!-- Begin Product Content Area -->
                                    <div class="product-content list-product_content">
                                        <h2 class="product-name">
                                            <a href="single-product">Printed Dress</a>
                                        </h2>
                                        <div class="rating-box">
                                            <ul class="rating">
                                                <li class="no-star"><i class="fa fa-star"></i></li>
                                                <li class="no-star"><i class="fa fa-star"></i></li>
                                                <li class="no-star"><i class="fa fa-star"></i></li>
                                                <li class="no-star"><i class="fa fa-star"></i></li>
                                                <li class="no-star"><i class="fa fa-star"></i></li>
                                            </ul>
                                        </div>
                                        <div class="price-box">
                                            <span class="new-price">$46.91</span>
                                        </div>
                                        <div class="product-action list-product_action">
                                            <ul class="product-action-link">
                                                <li class="shopping-cart_link"><a href="shopping-cart.html" title="Shopping Cart"><i class="ion-bag"></i></a></li>
                                                <li class="quick-view-btn"><a href="#" title="Quick View" data-toggle="modal" data-target="#exampleModalCenter"><i class="ion-eye"></i></a></li>
                                                <li class="single-product_link"><a href="product-details.html" title="Single Product"><i class="ion-link"></i></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <!-- Product Content Area End Here -->
                                </div>
                                <!-- Sigle Product Area End Here -->
                                <!-- Begin Sigle Product Area -->
                                <div class="single-product list-single_product">
                                    <!-- Begin Product Image Area -->
                                    <div class="product-img list-product_img">
                                        <a href="product-details.html">
                                            <img class="primary-img" src="assets/images/product/9.jpg" alt="FB'S Prduct">
                                        </a>
                                        <div class="sticker"><span>New</span></div>
                                    </div>
                                    <!-- Product Image Area End Here -->
                                    <!-- Begin Product Content Area -->
                                    <div class="product-content list-product_content">
                                        <h2 class="product-name">
                                            <a href="single-product">Printed Dress</a>
                                        </h2>
                                        <div class="rating-box">
                                            <ul class="rating">
                                                <li class="no-star"><i class="fa fa-star"></i></li>
                                                <li class="no-star"><i class="fa fa-star"></i></li>
                                                <li class="no-star"><i class="fa fa-star"></i></li>
                                                <li class="no-star"><i class="fa fa-star"></i></li>
                                                <li class="no-star"><i class="fa fa-star"></i></li>
                                            </ul>
                                        </div>
                                        <div class="price-box">
                                            <span class="new-price">$46.91</span>
                                        </div>
                                        <div class="product-action list-product_action">
                                            <ul class="product-action-link">
                                                <li class="shopping-cart_link"><a href="shopping-cart.html" title="Shopping Cart"><i class="ion-bag"></i></a></li>
                                                <li class="quick-view-btn"><a href="#" title="Quick View" data-toggle="modal" data-target="#exampleModalCenter"><i class="ion-eye"></i></a></li>
                                                <li class="single-product_link"><a href="product-details.html" title="Single Product"><i class="ion-link"></i></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <!-- Product Content Area End Here -->
                                </div>
                                <!-- Sigle Product Area End Here -->
                            </div>
                        </div>
                    </div>
                    <!-- FB's List Product Area End Here -->
                </div>
            </div>
        </div>
    </div>
</div>
<!-- FB's Banner With List Product Area End Here -->
<!-- Begin FB's Banner With List Product Area -->
<div class="fb-banner_with_list-product small-appliances_product pb-60">
    <div class="container">
        <div class="fb-product_list_nav">
            <div class="row no-gutters">
                <div class="col-xl-3 col-lg-4 col-md-5">
                    <div class="fb-section_title-2">
                        <h2>Small Appliances</h2>
                    </div>
                    <!-- Begin FB's Banner Area -->
                    <div class="fb-banner fb-img-hover-effect">
                        <a href="#">
                            <img src="assets/images/banner/1_8.jpg" alt="FB'S Banner">
                        </a>
                    </div>
                    <!-- FB's Banner Area End Here -->
                </div>
                <div class="col-xl-9 col-lg-8 col-md-7">
                    <div class="btn-group">
                        <button class="subcategories-trigger"><i class="fa fa-bars"></i></button>
                        <ul class="subcategories-list">
                         <li><a href="shop-left-sidebar.html" target="_blank">Bootees Bags</a></li>
                         <li><a href="shop-left-sidebar.html" target="_blank">Jackets</a></li>
                         <li><a href="shop-left-sidebar.html" target="_blank">Shelf</a></li>
                         <li><a href="shop-left-sidebar.html" target="_blank">Shoes</a></li>
                     </ul>
                     <!-- Begin FB's List Product Menu Area -->
                     <ul class="list-product_menu">
                        <li><a href="shop-left-sidebar.html" target="_blank">Bootees Bags</a></li>
                        <li><a href="shop-left-sidebar.html" target="_blank">Jackets</a></li>
                        <li><a href="shop-left-sidebar.html" target="_blank">Shelf</a></li>
                        <li><a href="shop-left-sidebar.html" target="_blank">Shoes</a></li>
                    </ul>
                    <!-- FB's List Product Menu Area End Here -->
                </div>
                <!-- Begin FB's List Product Area -->
                <div class="fb-list_product">
                    <div class="fb-list_product_active owl-carousel">
                        <div class="row no-gutters">
                            <!-- Begin Sigle Product Area -->
                            <div class="single-product list-single_product">
                                <!-- Begin Product Image Area -->
                                <div class="product-img list-product_img">
                                    <a href="product-details.html">
                                        <img class="primary-img" src="assets/images/product/13.jpg" alt="FB'S Prduct">
                                    </a>
                                    <div class="sticker"><span>New</span></div>
                                </div>
                                <!-- Product Image Area End Here -->
                                <!-- Begin Product Content Area -->
                                <div class="product-content list-product_content">
                                    <h2 class="product-name">
                                        <a href="single-product">Printed Dress</a>
                                    </h2>
                                    <div class="rating-box">
                                        <ul class="rating">
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                        </ul>
                                    </div>
                                    <div class="price-box">
                                        <span class="new-price">$46.91</span>
                                    </div>
                                    <div class="product-action list-product_action">
                                        <ul class="product-action-link">
                                            <li class="shopping-cart_link"><a href="shopping-cart.html" title="Shopping Cart"><i class="ion-bag"></i></a></li>
                                            <li class="quick-view-btn"><a href="#" title="Quick View" data-toggle="modal" data-target="#exampleModalCenter"><i class="ion-eye"></i></a></li>
                                            <li class="single-product_link"><a href="product-details.html" title="Single Product"><i class="ion-link"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- Product Content Area End Here -->
                            </div>
                            <!-- Sigle Product Area End Here -->
                            <!-- Begin Sigle Product Area -->
                            <div class="single-product list-single_product">
                                <!-- Begin Product Image Area -->
                                <div class="product-img list-product_img">
                                    <a href="product-details.html">
                                        <img class="primary-img" src="assets/images/product/12_1.jpg" alt="FB'S Prduct">
                                        <img class="secondary-img" src="assets/images/product/12_1.jpg" alt="FB'S Prduct">
                                    </a>
                                    <div class="sticker"><span>New</span></div>
                                </div>
                                <!-- Product Image Area End Here -->
                                <!-- Begin Product Content Area -->
                                <div class="product-content list-product_content">
                                    <h2 class="product-name">
                                        <a href="single-product">Printed Dress</a>
                                    </h2>
                                    <div class="rating-box">
                                        <ul class="rating">
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                        </ul>
                                    </div>
                                    <div class="price-box">
                                        <span class="new-price">$46.91</span>
                                    </div>
                                    <div class="product-action list-product_action">
                                        <ul class="product-action-link">
                                            <li class="shopping-cart_link"><a href="shopping-cart.html" title="Shopping Cart"><i class="ion-bag"></i></a></li>
                                            <li class="quick-view-btn"><a href="#" title="Quick View" data-toggle="modal" data-target="#exampleModalCenter"><i class="ion-eye"></i></a></li>
                                            <li class="single-product_link"><a href="product-details.html" title="Single Product"><i class="ion-link"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- Product Content Area End Here -->
                            </div>
                            <!-- Sigle Product Area End Here -->
                        </div>
                        <div class="row no-gutters">
                            <!-- Begin Sigle Product Area -->
                            <div class="single-product list-single_product">
                                <!-- Begin Product Image Area -->
                                <div class="product-img list-product_img">
                                    <a href="product-details.html">
                                        <img class="primary-img" src="assets/images/product/3_1.jpg" alt="FB'S Prduct">
                                        <img class="secondary-img" src="assets/images/product/3_2.jpg" alt="FB'S Prduct">
                                    </a>
                                    <div class="sticker"><span>New</span></div>
                                </div>
                                <!-- Product Image Area End Here -->
                                <!-- Begin Product Content Area -->
                                <div class="product-content list-product_content">
                                    <h2 class="product-name">
                                        <a href="single-product">Printed Dress</a>
                                    </h2>
                                    <div class="rating-box">
                                        <ul class="rating">
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                        </ul>
                                    </div>
                                    <div class="price-box">
                                        <span class="new-price">$46.91</span>
                                    </div>
                                    <div class="product-action list-product_action">
                                        <ul class="product-action-link">
                                            <li class="shopping-cart_link"><a href="shopping-cart.html" title="Shopping Cart"><i class="ion-bag"></i></a></li>
                                            <li class="quick-view-btn"><a href="#" title="Quick View" data-toggle="modal" data-target="#exampleModalCenter"><i class="ion-eye"></i></a></li>
                                            <li class="single-product_link"><a href="product-details.html" title="Single Product"><i class="ion-link"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- Product Content Area End Here -->
                            </div>
                            <!-- Sigle Product Area End Here -->
                            <!-- Begin Sigle Product Area -->
                            <div class="single-product list-single_product">
                                <!-- Begin Product Image Area -->
                                <div class="product-img list-product_img">
                                    <a href="product-details.html">
                                        <img class="primary-img" src="assets/images/product/1.jpg" alt="FB'S Prduct">
                                    </a>
                                    <div class="sticker"><span>New</span></div>
                                </div>
                                <!-- Product Image Area End Here -->
                                <!-- Begin Product Content Area -->
                                <div class="product-content list-product_content">
                                    <h2 class="product-name">
                                        <a href="single-product">Printed Dress</a>
                                    </h2>
                                    <div class="rating-box">
                                        <ul class="rating">
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                        </ul>
                                    </div>
                                    <div class="price-box">
                                        <span class="new-price">$46.91</span>
                                    </div>
                                    <div class="product-action list-product_action">
                                        <ul class="product-action-link">
                                            <li class="shopping-cart_link"><a href="shopping-cart.html" title="Shopping Cart"><i class="ion-bag"></i></a></li>
                                            <li class="quick-view-btn"><a href="#" title="Quick View" data-toggle="modal" data-target="#exampleModalCenter"><i class="ion-eye"></i></a></li>
                                            <li class="single-product_link"><a href="product-details.html" title="Single Product"><i class="ion-link"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- Product Content Area End Here -->
                            </div>
                            <!-- Sigle Product Area End Here -->
                        </div>
                        <div class="row no-gutters">
                            <!-- Begin Sigle Product Area -->
                            <div class="single-product list-single_product">
                                <!-- Begin Product Image Area -->
                                <div class="product-img list-product_img">
                                    <a href="product-details.html">
                                        <img class="primary-img" src="assets/images/product/13.jpg" alt="FB'S Prduct">
                                    </a>
                                    <div class="sticker"><span>New</span></div>
                                </div>
                                <!-- Product Image Area End Here -->
                                <!-- Begin Product Content Area -->
                                <div class="product-content list-product_content">
                                    <h2 class="product-name">
                                        <a href="single-product">Printed Dress</a>
                                    </h2>
                                    <div class="rating-box">
                                        <ul class="rating">
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                        </ul>
                                    </div>
                                    <div class="price-box">
                                        <span class="new-price">$46.91</span>
                                    </div>
                                    <div class="product-action list-product_action">
                                        <ul class="product-action-link">
                                            <li class="shopping-cart_link"><a href="shopping-cart.html" title="Shopping Cart"><i class="ion-bag"></i></a></li>
                                            <li class="quick-view-btn"><a href="#" title="Quick View" data-toggle="modal" data-target="#exampleModalCenter"><i class="ion-eye"></i></a></li>
                                            <li class="single-product_link"><a href="product-details.html" title="Single Product"><i class="ion-link"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- Product Content Area End Here -->
                            </div>
                            <!-- Sigle Product Area End Here -->
                            <!-- Begin Sigle Product Area -->
                            <div class="single-product list-single_product">
                                <!-- Begin Product Image Area -->
                                <div class="product-img list-product_img">
                                    <a href="product-details.html">
                                        <img class="primary-img" src="assets/images/product/12_1.jpg" alt="FB'S Prduct">
                                        <img class="secondary-img" src="assets/images/product/12_1.jpg" alt="FB'S Prduct">
                                    </a>
                                    <div class="sticker"><span>New</span></div>
                                </div>
                                <!-- Product Image Area End Here -->
                                <!-- Begin Product Content Area -->
                                <div class="product-content list-product_content">
                                    <h2 class="product-name">
                                        <a href="single-product">Printed Dress</a>
                                    </h2>
                                    <div class="rating-box">
                                        <ul class="rating">
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                        </ul>
                                    </div>
                                    <div class="price-box">
                                        <span class="new-price">$46.91</span>
                                    </div>
                                    <div class="product-action list-product_action">
                                        <ul class="product-action-link">
                                            <li class="shopping-cart_link"><a href="shopping-cart.html" title="Shopping Cart"><i class="ion-bag"></i></a></li>
                                            <li class="quick-view-btn"><a href="#" title="Quick View" data-toggle="modal" data-target="#exampleModalCenter"><i class="ion-eye"></i></a></li>
                                            <li class="single-product_link"><a href="product-details.html" title="Single Product"><i class="ion-link"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- Product Content Area End Here -->
                            </div>
                            <!-- Sigle Product Area End Here -->
                        </div>
                        <div class="row no-gutters">
                            <!-- Begin Sigle Product Area -->
                            <div class="single-product list-single_product">
                                <!-- Begin Product Image Area -->
                                <div class="product-img list-product_img">
                                    <a href="product-details.html">
                                        <img class="primary-img" src="assets/images/product/3_1.jpg" alt="FB'S Prduct">
                                        <img class="secondary-img" src="assets/images/product/3_2.jpg" alt="FB'S Prduct">
                                    </a>
                                    <div class="sticker"><span>New</span></div>
                                </div>
                                <!-- Product Image Area End Here -->
                                <!-- Begin Product Content Area -->
                                <div class="product-content list-product_content">
                                    <h2 class="product-name">
                                        <a href="single-product">Printed Dress</a>
                                    </h2>
                                    <div class="rating-box">
                                        <ul class="rating">
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                        </ul>
                                    </div>
                                    <div class="price-box">
                                        <span class="new-price">$46.91</span>
                                    </div>
                                    <div class="product-action list-product_action">
                                        <ul class="product-action-link">
                                            <li class="shopping-cart_link"><a href="shopping-cart.html" title="Shopping Cart"><i class="ion-bag"></i></a></li>
                                            <li class="quick-view-btn"><a href="#" title="Quick View" data-toggle="modal" data-target="#exampleModalCenter"><i class="ion-eye"></i></a></li>
                                            <li class="single-product_link"><a href="product-details.html" title="Single Product"><i class="ion-link"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- Product Content Area End Here -->
                            </div>
                            <!-- Sigle Product Area End Here -->
                            <!-- Begin Sigle Product Area -->
                            <div class="single-product list-single_product">
                                <!-- Begin Product Image Area -->
                                <div class="product-img list-product_img">
                                    <a href="product-details.html">
                                        <img class="primary-img" src="assets/images/product/1.jpg" alt="FB'S Prduct">
                                    </a>
                                    <div class="sticker"><span>New</span></div>
                                </div>
                                <!-- Product Image Area End Here -->
                                <!-- Begin Product Content Area -->
                                <div class="product-content list-product_content">
                                    <h2 class="product-name">
                                        <a href="single-product">Printed Dress</a>
                                    </h2>
                                    <div class="rating-box">
                                        <ul class="rating">
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                        </ul>
                                    </div>
                                    <div class="price-box">
                                        <span class="new-price">$46.91</span>
                                    </div>
                                    <div class="product-action list-product_action">
                                        <ul class="product-action-link">
                                            <li class="shopping-cart_link"><a href="shopping-cart.html" title="Shopping Cart"><i class="ion-bag"></i></a></li>
                                            <li class="quick-view-btn"><a href="#" title="Quick View" data-toggle="modal" data-target="#exampleModalCenter"><i class="ion-eye"></i></a></li>
                                            <li class="single-product_link"><a href="product-details.html" title="Single Product"><i class="ion-link"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- Product Content Area End Here -->
                            </div>
                            <!-- Sigle Product Area End Here -->
                        </div>
                    </div>
                </div>
                <!-- FB's List Product Area End Here -->
            </div>
        </div>
    </div>
</div>
</div>
<!-- FB's Banner With List Product Area End Here -->
<!-- Begin FB's Banner With List Product Area -->
<div class="fb-banner_with_list-product drinkware_product pb-60">
    <div class="container">
        <div class="fb-product_list_nav">
            <div class="row no-gutters">
                <div class="col-xl-3 col-lg-4 col-md-5">
                    <div class="fb-section_title-2">
                        <h2>Drinkware</h2>
                    </div>
                    <!-- Begin FB's Banner Area -->
                    <div class="fb-banner fb-img-hover-effect">
                        <a href="#">
                            <img src="assets/images/banner/1_9.jpg" alt="FB'S Banner">
                        </a>
                    </div>
                    <!-- FB's Banner Area End Here -->
                </div>
                <div class="col-xl-9 col-lg-8 col-md-7">
                    <div class="btn-group">
                        <button class="subcategories-trigger"><i class="fa fa-bars"></i></button>
                        <ul class="subcategories-list">
                         <li><a href="shop-left-sidebar.html" target="_blank">Tour Drinkware</a></li>
                         <li><a href="shop-left-sidebar.html" target="_blank">Hatch Drinkware</a></li>
                         <li><a href="shop-left-sidebar.html" target="_blank">Direction Drinkware</a></li>
                         <li><a href="shop-left-sidebar.html" target="_blank">Crescent Drinkware</a></li>
                     </ul>
                     <!-- Begin FB's List Product Menu Area -->
                     <ul class="list-product_menu">
                        <li><a href="shop-left-sidebar.html" target="_blank">Tour Drinkware</a></li>
                        <li><a href="shop-left-sidebar.html" target="_blank">Hatch Drinkware</a></li>
                        <li><a href="shop-left-sidebar.html" target="_blank">Direction Drinkware</a></li>
                        <li><a href="shop-left-sidebar.html" target="_blank">Crescent Drinkware</a></li>
                    </ul>
                    <!-- FB's List Product Menu Area End Here -->
                </div>
                <!-- Begin FB's List Product Area -->
                <div class="fb-list_product">
                    <div class="fb-list_product_active owl-carousel">
                        <div class="row no-gutters">
                            <!-- Begin Sigle Product Area -->
                            <div class="single-product list-single_product">
                                <!-- Begin Product Image Area -->
                                <div class="product-img list-product_img">
                                    <a href="product-details.html">
                                        <img class="primary-img" src="assets/images/product/13.jpg" alt="FB'S Prduct">
                                    </a>
                                    <div class="sticker"><span>New</span></div>
                                </div>
                                <!-- Product Image Area End Here -->
                                <!-- Begin Product Content Area -->
                                <div class="product-content list-product_content">
                                    <h2 class="product-name">
                                        <a href="single-product">Printed Dress</a>
                                    </h2>
                                    <div class="rating-box">
                                        <ul class="rating">
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                        </ul>
                                    </div>
                                    <div class="price-box">
                                        <span class="new-price">$46.91</span>
                                    </div>
                                    <div class="product-action list-product_action">
                                        <ul class="product-action-link">
                                            <li class="shopping-cart_link"><a href="shopping-cart.html" title="Shopping Cart"><i class="ion-bag"></i></a></li>
                                            <li class="quick-view-btn"><a href="#" title="Quick View" data-toggle="modal" data-target="#exampleModalCenter"><i class="ion-eye"></i></a></li>
                                            <li class="single-product_link"><a href="product-details.html" title="Single Product"><i class="ion-link"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- Product Content Area End Here -->
                            </div>
                            <!-- Sigle Product Area End Here -->
                            <!-- Begin Sigle Product Area -->
                            <div class="single-product list-single_product">
                                <!-- Begin Product Image Area -->
                                <div class="product-img list-product_img">
                                    <a href="product-details.html">
                                        <img class="primary-img" src="assets/images/product/12_1.jpg" alt="FB'S Prduct">
                                        <img class="secondary-img" src="assets/images/product/12_1.jpg" alt="FB'S Prduct">
                                    </a>
                                    <div class="sticker"><span>New</span></div>
                                </div>
                                <!-- Product Image Area End Here -->
                                <!-- Begin Product Content Area -->
                                <div class="product-content list-product_content">
                                    <h2 class="product-name">
                                        <a href="single-product">Printed Dress</a>
                                    </h2>
                                    <div class="rating-box">
                                        <ul class="rating">
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                        </ul>
                                    </div>
                                    <div class="price-box">
                                        <span class="new-price">$46.91</span>
                                    </div>
                                    <div class="product-action list-product_action">
                                        <ul class="product-action-link">
                                            <li class="shopping-cart_link"><a href="shopping-cart.html" title="Shopping Cart"><i class="ion-bag"></i></a></li>
                                            <li class="quick-view-btn"><a href="#" title="Quick View" data-toggle="modal" data-target="#exampleModalCenter"><i class="ion-eye"></i></a></li>
                                            <li class="single-product_link"><a href="product-details.html" title="Single Product"><i class="ion-link"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- Product Content Area End Here -->
                            </div>
                            <!-- Sigle Product Area End Here -->
                        </div>
                        <div class="row no-gutters">
                            <!-- Begin Sigle Product Area -->
                            <div class="single-product list-single_product">
                                <!-- Begin Product Image Area -->
                                <div class="product-img list-product_img">
                                    <a href="product-details.html">
                                        <img class="primary-img" src="assets/images/product/3_1.jpg" alt="FB'S Prduct">
                                        <img class="secondary-img" src="assets/images/product/3_2.jpg" alt="FB'S Prduct">
                                    </a>
                                    <div class="sticker"><span>New</span></div>
                                </div>
                                <!-- Product Image Area End Here -->
                                <!-- Begin Product Content Area -->
                                <div class="product-content list-product_content">
                                    <h2 class="product-name">
                                        <a href="single-product">Printed Dress</a>
                                    </h2>
                                    <div class="rating-box">
                                        <ul class="rating">
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                        </ul>
                                    </div>
                                    <div class="price-box">
                                        <span class="new-price">$46.91</span>
                                    </div>
                                    <div class="product-action list-product_action">
                                        <ul class="product-action-link">
                                            <li class="shopping-cart_link"><a href="shopping-cart.html" title="Shopping Cart"><i class="ion-bag"></i></a></li>
                                            <li class="quick-view-btn"><a href="#" title="Quick View" data-toggle="modal" data-target="#exampleModalCenter"><i class="ion-eye"></i></a></li>
                                            <li class="single-product_link"><a href="product-details.html" title="Single Product"><i class="ion-link"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- Product Content Area End Here -->
                            </div>
                            <!-- Sigle Product Area End Here -->
                            <!-- Begin Sigle Product Area -->
                            <div class="single-product list-single_product">
                                <!-- Begin Product Image Area -->
                                <div class="product-img list-product_img">
                                    <a href="product-details.html">
                                        <img class="primary-img" src="assets/images/product/1.jpg" alt="FB'S Prduct">
                                    </a>
                                    <div class="sticker"><span>New</span></div>
                                </div>
                                <!-- Product Image Area End Here -->
                                <!-- Begin Product Content Area -->
                                <div class="product-content list-product_content">
                                    <h2 class="product-name">
                                        <a href="single-product">Printed Dress</a>
                                    </h2>
                                    <div class="rating-box">
                                        <ul class="rating">
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                        </ul>
                                    </div>
                                    <div class="price-box">
                                        <span class="new-price">$46.91</span>
                                    </div>
                                    <div class="product-action list-product_action">
                                        <ul class="product-action-link">
                                            <li class="shopping-cart_link"><a href="shopping-cart.html" title="Shopping Cart"><i class="ion-bag"></i></a></li>
                                            <li class="quick-view-btn"><a href="#" title="Quick View" data-toggle="modal" data-target="#exampleModalCenter"><i class="ion-eye"></i></a></li>
                                            <li class="single-product_link"><a href="product-details.html" title="Single Product"><i class="ion-link"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- Product Content Area End Here -->
                            </div>
                            <!-- Sigle Product Area End Here -->
                        </div>
                        <div class="row no-gutters">
                            <!-- Begin Sigle Product Area -->
                            <div class="single-product list-single_product">
                                <!-- Begin Product Image Area -->
                                <div class="product-img list-product_img">
                                    <a href="product-details.html">
                                        <img class="primary-img" src="assets/images/product/13.jpg" alt="FB'S Prduct">
                                    </a>
                                    <div class="sticker"><span>New</span></div>
                                </div>
                                <!-- Product Image Area End Here -->
                                <!-- Begin Product Content Area -->
                                <div class="product-content list-product_content">
                                    <h2 class="product-name">
                                        <a href="single-product">Printed Dress</a>
                                    </h2>
                                    <div class="rating-box">
                                        <ul class="rating">
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                        </ul>
                                    </div>
                                    <div class="price-box">
                                        <span class="new-price">$46.91</span>
                                    </div>
                                    <div class="product-action list-product_action">
                                        <ul class="product-action-link">
                                            <li class="shopping-cart_link"><a href="shopping-cart.html" title="Shopping Cart"><i class="ion-bag"></i></a></li>
                                            <li class="quick-view-btn"><a href="#" title="Quick View" data-toggle="modal" data-target="#exampleModalCenter"><i class="ion-eye"></i></a></li>
                                            <li class="single-product_link"><a href="product-details.html" title="Single Product"><i class="ion-link"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- Product Content Area End Here -->
                            </div>
                            <!-- Sigle Product Area End Here -->
                            <!-- Begin Sigle Product Area -->
                            <div class="single-product list-single_product">
                                <!-- Begin Product Image Area -->
                                <div class="product-img list-product_img">
                                    <a href="product-details.html">
                                        <img class="primary-img" src="assets/images/product/12_1.jpg" alt="FB'S Prduct">
                                        <img class="secondary-img" src="assets/images/product/12_1.jpg" alt="FB'S Prduct">
                                    </a>
                                    <div class="sticker"><span>New</span></div>
                                </div>
                                <!-- Product Image Area End Here -->
                                <!-- Begin Product Content Area -->
                                <div class="product-content list-product_content">
                                    <h2 class="product-name">
                                        <a href="single-product">Printed Dress</a>
                                    </h2>
                                    <div class="rating-box">
                                        <ul class="rating">
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                        </ul>
                                    </div>
                                    <div class="price-box">
                                        <span class="new-price">$46.91</span>
                                    </div>
                                    <div class="product-action list-product_action">
                                        <ul class="product-action-link">
                                            <li class="shopping-cart_link"><a href="shopping-cart.html" title="Shopping Cart"><i class="ion-bag"></i></a></li>
                                            <li class="quick-view-btn"><a href="#" title="Quick View" data-toggle="modal" data-target="#exampleModalCenter"><i class="ion-eye"></i></a></li>
                                            <li class="single-product_link"><a href="product-details.html" title="Single Product"><i class="ion-link"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- Product Content Area End Here -->
                            </div>
                            <!-- Sigle Product Area End Here -->
                        </div>
                        <div class="row no-gutters">
                            <!-- Begin Sigle Product Area -->
                            <div class="single-product list-single_product">
                                <!-- Begin Product Image Area -->
                                <div class="product-img list-product_img">
                                    <a href="product-details.html">
                                        <img class="primary-img" src="assets/images/product/3_1.jpg" alt="FB'S Prduct">
                                        <img class="secondary-img" src="assets/images/product/3_2.jpg" alt="FB'S Prduct">
                                    </a>
                                    <div class="sticker"><span>New</span></div>
                                </div>
                                <!-- Product Image Area End Here -->
                                <!-- Begin Product Content Area -->
                                <div class="product-content list-product_content">
                                    <h2 class="product-name">
                                        <a href="single-product">Printed Dress</a>
                                    </h2>
                                    <div class="rating-box">
                                        <ul class="rating">
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                        </ul>
                                    </div>
                                    <div class="price-box">
                                        <span class="new-price">$46.91</span>
                                    </div>
                                    <div class="product-action list-product_action">
                                        <ul class="product-action-link">
                                            <li class="shopping-cart_link"><a href="shopping-cart.html" title="Shopping Cart"><i class="ion-bag"></i></a></li>
                                            <li class="quick-view-btn"><a href="#" title="Quick View" data-toggle="modal" data-target="#exampleModalCenter"><i class="ion-eye"></i></a></li>
                                            <li class="single-product_link"><a href="product-details.html" title="Single Product"><i class="ion-link"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- Product Content Area End Here -->
                            </div>
                            <!-- Sigle Product Area End Here -->
                            <!-- Begin Sigle Product Area -->
                            <div class="single-product list-single_product">
                                <!-- Begin Product Image Area -->
                                <div class="product-img list-product_img">
                                    <a href="product-details.html">
                                        <img class="primary-img" src="assets/images/product/1.jpg" alt="FB'S Prduct">
                                    </a>
                                    <div class="sticker"><span>New</span></div>
                                </div>
                                <!-- Product Image Area End Here -->
                                <!-- Begin Product Content Area -->
                                <div class="product-content list-product_content">
                                    <h2 class="product-name">
                                        <a href="single-product">Printed Dress</a>
                                    </h2>
                                    <div class="rating-box">
                                        <ul class="rating">
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                            <li class="no-star"><i class="fa fa-star"></i></li>
                                        </ul>
                                    </div>
                                    <div class="price-box">
                                        <span class="new-price">$46.91</span>
                                    </div>
                                    <div class="product-action list-product_action">
                                        <ul class="product-action-link">
                                            <li class="shopping-cart_link"><a href="shopping-cart.html" title="Shopping Cart"><i class="ion-bag"></i></a></li>
                                            <li class="quick-view-btn"><a href="#" title="Quick View" data-toggle="modal" data-target="#exampleModalCenter"><i class="ion-eye"></i></a></li>
                                            <li class="single-product_link"><a href="product-details.html" title="Single Product"><i class="ion-link"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- Product Content Area End Here -->
                            </div>
                            <!-- Sigle Product Area End Here -->
                        </div>
                    </div>
                </div>
                <!-- FB's List Product Area End Here -->
            </div>
        </div>
    </div>
</div>
</div>
<!-- FB's Banner With List Product Area End Here -->

<!--begin bottom banner are -->
<?php echo $__env->make('frontEnd.pages.home.container.bottom-banner', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!--end bottom banner are -->





</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>